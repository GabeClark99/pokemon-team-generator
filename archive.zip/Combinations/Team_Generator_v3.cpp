// type chart source: https://github.com/zonination/pokemon-chart/blob/master/chart.csv

#include <iostream>
#include <string>
#include <list>
#include <fstream>
#include <sstream>
#include <vector>
#include <tuple>
#include <algorithm>
#include <iterator>
#include <filesystem>
#include <chrono>
#include <iomanip>

using namespace std;

static const string fileName_typeChart = "typeChart.csv";
static const string fileName_typeCombos = "typeCombos.csv";
static const string fileName_state = "saveState.txt";

class PokemonType {
    public:
        string name;
        list<string> supEff;
        list<string> nvEff;
        list<string> imm;
        list<string> neu;

        PokemonType(string newName, list<string> newSupEff, list<string> newNvEff, list<string> newImm, list<string> newNeu) {
            name = newName;
            supEff = newSupEff;
            nvEff = newNvEff;
            imm = newImm;
            neu = newNeu;
        }
};

class TeamGenerator {
    vector<int> indices;
    int n;
    int r;
    bool done;

public:
    TeamGenerator(int n, int r) : n(n), r(r), done(false) {
        indices.resize(r);
        for (int i = 0; i < r; ++i) {
            indices[i] = i; // Initialize with the first combination
        }
    }

    vector<tuple<PokemonType,PokemonType>> next_team(vector<tuple<PokemonType,PokemonType>> typeCombos) {
        if(done) {
            return {};
        }

        // setup the current combo
        vector<tuple<PokemonType, PokemonType>> team;
        for (int i = 0; i < r; ++i) {
            team.push_back(typeCombos[indices[i]]);  
        }

        // generate the next combo
        int i;
        for(i = r-1; i >=0; --i) {
            if(indices[i] < n-r+i) {
                ++indices[i];
                for(int j = i+1; j < r; ++j) {
                    indices[j] = indices[j-1]+1;
                }
                break;
            }
        }

        if(i < 0) {done = true;} // no more combos are possible

        return team;
    }

    bool is_done() const {
        return done;
    }

    vector<int>& get_indices() {
        return indices;
    }

    // Set the done flag (used when loading the state)
    void set_done(bool done) {
        this->done = done;
    }
};

class StateManager {
public:
    // Save the state (team generator state, best team, and score)
    static void save_state(TeamGenerator& gen, const string& filename, 
                           const string& bestTeam, 
                           double best_score) {
        ofstream file(filename);
        if (file) {
            // Save the indices
            const vector<int>& indices = gen.get_indices();
            for (int idx : indices) {
                file << idx << " ";
            }
            file << endl;

            // Save the "done" flag
            file << gen.is_done() << endl;

            // Save the best score
            file << best_score << endl;

            // Save the best team (convert the tuple to a string format)
            file << bestTeam;
            file << endl;
        }
    }

    // Load the state (team generator state, best team, and score)
    static bool load_state(TeamGenerator& gen, const string& filename, 
                           string& best_team, 
                           double& best_score) {
        ifstream file(filename);
        if (file) {
            // Load the indices
            vector<int>& indices = gen.get_indices();
            for (int i = 0; i < indices.size(); ++i) {
                file >> indices[i];
            }

            // Load the "done" flag
            bool done;
            file >> done;
            gen.set_done(done);

            // Load the best score
            file >> best_score;

            // Load the best team (assuming the team has the same structure)
            best_team.clear();
            file >> best_team;

            return true;
        }
        return false;
    }

    static void create_backup(const string& filename) {
        string backup_filename = generate_backup_filename(filename);
        filesystem::copy_file(filename, backup_filename, 
                              filesystem::copy_options::overwrite_existing);
        
        return;
    }

private:
    // Generates a unique backup filename with a timestamp
    static string generate_backup_filename(const string& original_filename) {
        auto now = std::chrono::system_clock::now();
        auto time_t_now = std::chrono::system_clock::to_time_t(now);
        std::ostringstream oss;
        oss << original_filename << ".backup_"
            << std::put_time(std::localtime(&time_t_now), "%Y%m%d_%H%M%S");
        return oss.str();
    }
};

vector<string> Tokenize(string s, char delim = ',') {
    vector<string> tokens;

    std::stringstream ss(s);
    string token;
    while (!ss.eof()) {
        getline(ss, token, delim);
        tokens.push_back(token);
    }

    return tokens;
}

template <class T> void Print(T li) {
    for(string s : li) {
        cout << s << " ";
    }
    cout << endl;

    return;
}

void PrintTypes(list<PokemonType> pTypes) {
    cout << "Types: ";
    for(PokemonType t : pTypes) {
        cout << t.name << " ";
    }
    cout << endl;

    return;
}

list<PokemonType> ImportTypes() {
    list<PokemonType> pTypes;
    std::ifstream fileIn(fileName_typeChart);
    if(!fileIn.is_open()) {std::cerr << "Error opening file!";}

    string line;
    vector<string> lineData;
    string attackingType;
    

    getline(fileIn, line);
    vector<string> defendingTypes = Tokenize(line.substr(10));
    // PrintVector(defendingTypes);
    while(getline(fileIn, line)) {
        list<string> lineSupEff;
        list<string> lineNvEff;
        list<string> lineImm;
        list<string> lineNeu;
        // cout << line << endl;
        lineData = Tokenize(line, ',');

        attackingType = lineData[0];
        for(int i=1; i < lineData.size(); ++i) {
            string defendingType = defendingTypes[i-1];
            // cout << defendingType << endl;
            int value = stod(lineData[i]) * 10.0;
            // cout << value << endl;
            // cout << attackingType << " vs " << defendingType << ": " << value << endl;
            switch(value) {
                case 20:
                    lineSupEff.push_back(defendingType); break;
                case 10:
                    lineNeu.push_back(defendingType); break;
                case 5:
                    lineNvEff.push_back(defendingType); break;
                case 0:
                    lineImm.push_back(defendingType); break;
                default:
                    throw std::runtime_error("Invalid type chart case: \"" + std::to_string(value) + "\" at i=" + std::to_string(i));
            }
        }
        pTypes.push_back(PokemonType(attackingType, lineSupEff, lineNvEff, lineImm, lineNeu));
    }

    fileIn.close();
    return pTypes;
}

PokemonType GetType(list<PokemonType> pTypes, string typeName) {
    for(PokemonType t : pTypes) {
        if(t.name == typeName) {
            return t;
        }
    }
    throw std::runtime_error("Type name not found: \"" + typeName + "\"");
}

void PrintTuple(tuple<PokemonType,PokemonType> tup) {
    cout << get<0>(tup).name.substr(0,3) + "," + get<1>(tup).name.substr(0,3);
    return;
}

string TupleToString(tuple<PokemonType,PokemonType> tup) {
    return get<0>(tup).name.substr(0,3) + "," + get<1>(tup).name.substr(0,3);
}

void PrintTypeCombos(vector<tuple<PokemonType,PokemonType>> v) {
    cout << "Team: ";
    PrintTuple(*v.begin());
    for(int i=1; i < v.size(); ++i) {
        cout << " | ";
        PrintTuple(v[i]); 
    }
    cout << endl;

    return;
}

string TypeCombosToString(vector<tuple<PokemonType,PokemonType>> combos) {
    string output = TupleToString(*combos.begin());
    for(int i=1; i < combos.size(); ++i) {
        output += " | ";
        output += TupleToString(combos[i]);
    }

    return output;
}

vector<tuple<PokemonType,PokemonType>> ImportTypeCombos(list<PokemonType> pTypes) {
    vector<tuple<PokemonType,PokemonType>> typeCombos;

    std::ifstream fileIn(fileName_typeCombos);
    if(!fileIn.is_open()) {std::cerr << "Error opening file!";}

    string line;
    vector<string> lineData;

    while(getline(fileIn, line)) {
        lineData = Tokenize(line, ',');

        string typeNameA = lineData[0];
        string typeNameB = lineData[1];
        // cout << typeNameA + " " + typeNameB << endl;

        PokemonType typeA = GetType(pTypes, typeNameA);
        PokemonType typeB = GetType(pTypes, typeNameB);
        // cout << typeA.name + " " + typeB.name << endl;

        typeCombos.push_back(tuple<PokemonType,PokemonType>(typeA,typeB));
    }

    fileIn.close();
    return typeCombos;
}

list<PokemonType> GetUniqueTypes(vector<tuple<PokemonType,PokemonType>> team, 
                                   list<PokemonType> pTypes) {
    list<PokemonType> uniqueTypes;

    for(tuple<PokemonType,PokemonType> tup : team) {
        PokemonType typeA = get<0>(tup);
        PokemonType typeB = get<1>(tup);

        bool aFound = false;
        bool bFound = false;
        for(PokemonType t : uniqueTypes) {
            if(t.name == typeA.name) {aFound = true;}
            if(t.name == typeB.name) {bFound = true;}
        }
        // cout << "aFound=" << aFound << ", bFound=" << bFound << endl;

        if(!aFound) {uniqueTypes.push_back(typeA);}
        if(!bFound) {uniqueTypes.push_back(typeB);}
    }

    return uniqueTypes;
}

template <class T> bool TypeIsInList(T toFind, list<T> li) {
    for(T element : li) {
        if(element == toFind) {
            // cout << "\t\t\t" << element << "==" << toFind << endl;
            return true;
        }
    }

    return false;
}

double GetEffectiveness(PokemonType att, PokemonType def) {
    if(TypeIsInList(def.name, att.supEff)) {
        return 2.0;
    }
    else if (TypeIsInList(def.name, att.neu)) {
        return 1.0;
    }
    else if (TypeIsInList(def.name, att.nvEff)) {
        return 0.5;
    }
    else if (TypeIsInList(def.name, att.imm)) {
        return 0.0;
    }
    else {
        throw std::runtime_error("Attacking type not found in Defending type's lists: \"" + att.name + "\"");
    }
}

double GetEffectiveness(PokemonType attType, tuple<PokemonType,PokemonType> defCombo) {
    return GetEffectiveness(attType, get<0>(defCombo)) * GetEffectiveness(attType, get<1>(defCombo));
}

double CalculateAttackingValue(list<PokemonType> attackingTypes, 
                            vector<tuple<PokemonType,PokemonType>> typeCombos) {
    double attackingValue = 0.0;

    for(tuple<PokemonType,PokemonType> combo : typeCombos) {
        double bestHit = 0.0;
        // cout << "\tcombo: "; PrintTuple(combo); cout << endl;
        for(PokemonType attType : attackingTypes) {
            // double effVsTypeA, effVsTypeB = 0.0;
            
            // effVsTypeA = GetEffectiveness(attType, get<0>(combo));
            // effVsTypeB = GetEffectiveness(attType, get<1>(combo));

            // double totEff = effVsTypeA * effVsTypeB;
            double totEff = GetEffectiveness(attType, combo);
            // cout << "\t\t" << attType.name << ": " << totEff << endl;

            if(totEff > bestHit) {
                bestHit = totEff;
            }

            // cout << "\t\t" << attType.name << " vs " << get<0>(combo).name << ": " << effVsTypeA << endl;
            // cout << "\t\t" << attType.name << " vs " << get<1>(combo).name << ": " << effVsTypeB << endl;
        }
        // cout << "\tbestHit=" << bestHit << endl << endl;
        attackingValue += bestHit;
    }

    

    return attackingValue;
}

void PrintTypeEff(list<PokemonType> pTypes) {
    for(PokemonType i : pTypes) {
        cout << "Name: " << i.name << endl;
        cout << "\tSuper Effective vs: ";
        for(string j : i.supEff) {
            cout << j << " ";
        }
        cout << endl;
    }
}

double CalculateDefenseValue(vector<tuple<PokemonType,PokemonType>> team, 
                             list<PokemonType> pTypes) {
    double defValue = 0.0;

    for(PokemonType attType : pTypes) {
        // cout << "\t" << attType.name << ": " << endl;
        for(tuple<PokemonType,PokemonType> combo : team) {
            double defEff = GetEffectiveness(attType, combo);
            // cout << "\t\t" << "vs " << TupleToString(combo) << ": " << defEff << endl;
            defValue += defEff;
        }
    }

    return defValue;
}

string TypeComboListToString(vector<tuple<PokemonType,PokemonType>> team) {
    string output = "";

    for(const auto& tup : team) {
        output += get<0>(tup).name + "," + get<1>(tup).name + " ";
    }

    return output;
}

void CalculateScores(const vector<tuple<PokemonType,PokemonType>> team, 
                     const list<PokemonType> pTypes, 
                     const vector<tuple<PokemonType,PokemonType>> typeCombos,
                     double &attScore, double &defScore) {
    list<PokemonType> uniqueTypes = GetUniqueTypes(team, pTypes);
    attScore = CalculateAttackingValue(uniqueTypes, typeCombos);
    defScore = CalculateDefenseValue(team, pTypes);

    return;
}

int main() {
    const list<PokemonType> pTypes = ImportTypes();

    const vector<tuple<PokemonType,PokemonType>> typeCombos = ImportTypeCombos(pTypes);

    const int r = 6;
    const int n = typeCombos.size();
    TeamGenerator gen(n, r);

    string bestTeam;
    double bestScore = -1.0;

    if(!StateManager::load_state(gen, fileName_state, bestTeam, bestScore)) {
        cout << "Starting new generation..." << endl;
    }
    else {
        cout << "Resuming from saved state..." << endl;
        StateManager::create_backup(fileName_state);
    }
    
    int i = 0;
    int batchSize = 10000;
    list<PokemonType> uniqueTypes;
    vector<tuple<PokemonType,PokemonType>> team = gen.next_team(typeCombos);
    while(!team.empty()) {
        double attScore;
        double defScore;

        CalculateScores(team, pTypes, typeCombos, attScore, defScore);

        double totalScore = attScore - defScore;
        if(totalScore > bestScore) {
            bestTeam = TypeComboListToString(team);
            bestScore = totalScore;
        }
        // cout << "Total Value: " << attScore - defScore << endl;
        // cout << endl;

        team = gen.next_team(typeCombos);
        ++i;

        // After processing each batch, save the state
        if(i % batchSize == 0) {
            cout << "Processed " << i << " combinations, saving state..." << endl;
            StateManager::save_state(gen, fileName_state, bestTeam, bestScore);
            cout << "\t State saved." << endl;
        }
    }

    // Save the final state after the last batch
    StateManager::save_state(gen, fileName_state, bestTeam, bestScore);

    cout << "Best Team: " << bestTeam << endl;
    cout << "Total Score: " << bestScore << endl;

    cout << "Finished processing all combinations.";

    return 0;
}