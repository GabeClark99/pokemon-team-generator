// type chart source: https://github.com/zonination/pokemon-chart/blob/master/chart.csv

#include <iostream>
#include <string>
#include <list>
#include <fstream>
#include <sstream>
#include <vector>
#include <tuple>
#include <algorithm>
#include <iterator>
#include <filesystem>
#include <chrono>
#include <iomanip>
#include <random>

using namespace std;

static const string fileName_typeChart = "typeChart.csv";
static const string fileName_typeCombos = "typeCombos.csv";
static const string fileName_state = "saveState.txt";

class PokemonType {
    public:
        string name;
        list<string> supEff;
        list<string> nvEff;
        list<string> imm;
        list<string> neu;

        PokemonType(string newName, list<string> newSupEff, list<string> newNvEff, list<string> newImm, list<string> newNeu) {
            name = newName;
            supEff = newSupEff;
            nvEff = newNvEff;
            imm = newImm;
            neu = newNeu;
        }
};

class TeamGenerator {
    default_random_engine rng;

public:
    TeamGenerator() {
        rng = default_random_engine {};
    }

    vector<tuple<PokemonType,PokemonType>> next_team(vector<tuple<PokemonType,PokemonType>> typeCombos) {
        shuffle(typeCombos.begin(), typeCombos.end(), rng);
        vector<tuple<PokemonType,PokemonType>> newTeam(typeCombos.begin(), 
                                                       typeCombos.begin() + 6);

        return newTeam;
    }
};

class StateManager {
public:
    // Save the state (team generator state, best team, and score)
    static void save_state(const string filename, 
                           const string bestTeam, 
                           const double best_score) {
        ofstream file(filename);
        if (file) {
            // Save the best score
            file << best_score << endl;

            // Save the best team
            file << bestTeam;
            file << endl;
        }
    }

    // Load the state (team generator state, best team, and score)
    static bool load_state(const string filename, 
                           string& best_team, 
                           double& best_score) {
        ifstream file(filename);
        if (file) {
            // Load the best score
            file >> best_score;

            // Load the best team
            best_team.clear();
            file >> best_team;

            return true;
        }
        return false;
    }

    static void create_backup(const string& filename) {
        string backup_filename = generate_backup_filename(filename);
        filesystem::copy_file(filename, backup_filename, 
                              filesystem::copy_options::overwrite_existing);
        
        return;
    }

private:
    // Generates a unique backup filename with a timestamp
    static string generate_backup_filename(const string& original_filename) {
        auto now = std::chrono::system_clock::now();
        auto time_t_now = std::chrono::system_clock::to_time_t(now);
        std::ostringstream oss;
        oss << original_filename << ".backup_"
            << std::put_time(std::localtime(&time_t_now), "%Y%m%d_%H%M%S");
        return oss.str();
    }
};

vector<string> Tokenize(string s, char delim = ',') {
    vector<string> tokens;

    std::stringstream ss(s);
    string token;
    while (!ss.eof()) {
        getline(ss, token, delim);
        tokens.push_back(token);
    }

    return tokens;
}

template <class T> void Print(T li) {
    for(string s : li) {
        cout << s << " ";
    }
    cout << endl;

    return;
}

void PrintTypes(list<PokemonType> pTypes) {
    cout << "Types: ";
    for(PokemonType t : pTypes) {
        cout << t.name << " ";
    }
    cout << endl;

    return;
}

list<PokemonType> ImportTypes() {
    list<PokemonType> pTypes;
    std::ifstream fileIn(fileName_typeChart);
    if(!fileIn.is_open()) {std::cerr << "Error opening file!";}

    string line;
    vector<string> lineData;
    string attackingType;
    

    getline(fileIn, line);
    vector<string> defendingTypes = Tokenize(line.substr(10));
    // PrintVector(defendingTypes);
    while(getline(fileIn, line)) {
        list<string> lineSupEff;
        list<string> lineNvEff;
        list<string> lineImm;
        list<string> lineNeu;
        // cout << line << endl;
        lineData = Tokenize(line, ',');

        attackingType = lineData[0];
        for(int i=1; i < lineData.size(); ++i) {
            string defendingType = defendingTypes[i-1];
            // cout << defendingType << endl;
            int value = stod(lineData[i]) * 10.0;
            // cout << value << endl;
            // cout << attackingType << " vs " << defendingType << ": " << value << endl;
            switch(value) {
                case 20:
                    lineSupEff.push_back(defendingType); break;
                case 10:
                    lineNeu.push_back(defendingType); break;
                case 5:
                    lineNvEff.push_back(defendingType); break;
                case 0:
                    lineImm.push_back(defendingType); break;
                default:
                    throw std::runtime_error("Invalid type chart case: \"" + std::to_string(value) + "\" at i=" + std::to_string(i));
            }
        }
        pTypes.push_back(PokemonType(attackingType, lineSupEff, lineNvEff, lineImm, lineNeu));
    }

    fileIn.close();
    return pTypes;
}

PokemonType GetType(list<PokemonType> pTypes, string typeName) {
    for(PokemonType t : pTypes) {
        if(t.name == typeName) {
            return t;
        }
    }
    throw std::runtime_error("Type name not found: \"" + typeName + "\"");
}

void PrintTuple(tuple<PokemonType,PokemonType> tup) {
    cout << get<0>(tup).name.substr(0,3) + "," + get<1>(tup).name.substr(0,3);
    return;
}

string TupleToString(tuple<PokemonType,PokemonType> tup) {
    return get<0>(tup).name.substr(0,3) + "," + get<1>(tup).name.substr(0,3);
}

void PrintTypeCombos(vector<tuple<PokemonType,PokemonType>> v) {
    cout << "Team: ";
    PrintTuple(*v.begin());
    for(int i=1; i < v.size(); ++i) {
        cout << " | ";
        PrintTuple(v[i]); 
    }
    cout << endl;

    return;
}

string TypeCombosToString(vector<tuple<PokemonType,PokemonType>> combos) {
    string output = TupleToString(*combos.begin());
    for(int i=1; i < combos.size(); ++i) {
        output += " | ";
        output += TupleToString(combos[i]);
    }

    return output;
}

vector<tuple<PokemonType,PokemonType>> ImportTypeCombos(list<PokemonType> pTypes) {
    vector<tuple<PokemonType,PokemonType>> typeCombos;

    std::ifstream fileIn(fileName_typeCombos);
    if(!fileIn.is_open()) {std::cerr << "Error opening file!";}

    string line;
    vector<string> lineData;

    while(getline(fileIn, line)) {
        lineData = Tokenize(line, ',');

        string typeNameA = lineData[0];
        string typeNameB = lineData[1];
        // cout << typeNameA + " " + typeNameB << endl;

        PokemonType typeA = GetType(pTypes, typeNameA);
        PokemonType typeB = GetType(pTypes, typeNameB);
        // cout << typeA.name + " " + typeB.name << endl;

        typeCombos.push_back(tuple<PokemonType,PokemonType>(typeA,typeB));
    }

    fileIn.close();
    return typeCombos;
}

list<PokemonType> GetUniqueTypes(vector<tuple<PokemonType,PokemonType>> team, 
                                   list<PokemonType> pTypes) {
    list<PokemonType> uniqueTypes;

    for(tuple<PokemonType,PokemonType> tup : team) {
        PokemonType typeA = get<0>(tup);
        PokemonType typeB = get<1>(tup);

        bool aFound = false;
        bool bFound = false;
        for(PokemonType t : uniqueTypes) {
            if(t.name == typeA.name) {aFound = true;}
            if(t.name == typeB.name) {bFound = true;}
        }
        // cout << "aFound=" << aFound << ", bFound=" << bFound << endl;

        if(!aFound) {uniqueTypes.push_back(typeA);}
        if(!bFound) {uniqueTypes.push_back(typeB);}
    }

    return uniqueTypes;
}

template <class T> bool TypeIsInList(T toFind, list<T> li) {
    for(T element : li) {
        if(element == toFind) {
            // cout << "\t\t\t" << element << "==" << toFind << endl;
            return true;
        }
    }

    return false;
}

double GetEffectiveness(PokemonType att, PokemonType def) {
    if(TypeIsInList(def.name, att.supEff)) {
        return 2.0;
    }
    else if (TypeIsInList(def.name, att.neu)) {
        return 1.0;
    }
    else if (TypeIsInList(def.name, att.nvEff)) {
        return 0.5;
    }
    else if (TypeIsInList(def.name, att.imm)) {
        return 0.0;
    }
    else {
        throw std::runtime_error("Attacking type not found in Defending type's lists: \"" + att.name + "\"");
    }
}

double GetEffectiveness(PokemonType attType, tuple<PokemonType,PokemonType> defCombo) {
    return GetEffectiveness(attType, get<0>(defCombo)) * GetEffectiveness(attType, get<1>(defCombo));
}

double CalculateAttackingValue(list<PokemonType> attackingTypes, 
                            vector<tuple<PokemonType,PokemonType>> typeCombos) {
    double attackingValue = 0.0;

    for(tuple<PokemonType,PokemonType> combo : typeCombos) {
        double bestHit = 0.0;
        // cout << "\tcombo: "; PrintTuple(combo); cout << endl;
        for(PokemonType attType : attackingTypes) {
            // double effVsTypeA, effVsTypeB = 0.0;
            
            // effVsTypeA = GetEffectiveness(attType, get<0>(combo));
            // effVsTypeB = GetEffectiveness(attType, get<1>(combo));

            // double totEff = effVsTypeA * effVsTypeB;
            double totEff = GetEffectiveness(attType, combo);
            // cout << "\t\t" << attType.name << ": " << totEff << endl;

            if(totEff > bestHit) {
                bestHit = totEff;
            }

            // cout << "\t\t" << attType.name << " vs " << get<0>(combo).name << ": " << effVsTypeA << endl;
            // cout << "\t\t" << attType.name << " vs " << get<1>(combo).name << ": " << effVsTypeB << endl;
        }
        // cout << "\tbestHit=" << bestHit << endl << endl;
        attackingValue += bestHit;
    }

    

    return attackingValue / 6.0;
}

void PrintTypeEff(list<PokemonType> pTypes) {
    for(PokemonType i : pTypes) {
        cout << "Name: " << i.name << endl;
        cout << "\tSuper Effective vs: ";
        for(string j : i.supEff) {
            cout << j << " ";
        }
        cout << endl;
    }
}

double CalculateDefenseValue(vector<tuple<PokemonType,PokemonType>> team, 
                             list<PokemonType> pTypes) {
    double defValue = 0.0;

    for(PokemonType attType : pTypes) {
        // cout << "\t" << attType.name << ": " << endl;
        for(tuple<PokemonType,PokemonType> combo : team) {
            double defEff = GetEffectiveness(attType, combo);
            // cout << "\t\t" << "vs " << TupleToString(combo) << ": " << defEff << endl;
            defValue += defEff;
        }
    }

    return defValue / 6.0;
}

string TypeComboListToString(vector<tuple<PokemonType,PokemonType>> team) {
    string output = "";

    for(const auto& tup : team) {
        output += get<0>(tup).name + "," + get<1>(tup).name + " ";
    }

    return output;
}

template <class T> CombineVectors(vector<T> v1, vector<T> v2) {
    // vector<T> newVec(v1.begin(), v1.end());
    vector<T> newVec = v1;
    newVec.insert(newVec.end(), v2.begin(), v2.end());
    return newVec;
}

// void PrintShittyTypeCombos(vector<tuple<PokemonType,PokemonType>> combos) {
//     for(tuple<PokemonType,PokemonType> c : combos) {
//         vector<string> typeA_weak(get<0>(c).supEff.begin(), get<0>(c).supEff.end());
//         vector<string> typeA_res(get<0>(c).res.begin(), get<0>(c).res.end());
//         vector<string> typeA_imm(get<0>(c).imm.begin(), get<0>(c).imm.end());

//         vector<string> typeB_weak(get<1>(c).supEff.begin(), get<1>(c).supEff.end());
//         vector<string> typeB_res(get<1>(c).res.begin(), get<1>(c).res.end());
//         vector<string> typeB_imm(get<1>(c).imm.begin(), get<1>(c).imm.end());

//         vector<string> total_weak = CombineVectors(typeA_weak, typeB_weak);
//         vector<string> total_res = CombineVectors(typeA_res, typeB_res);
//         vector<string> total_imm = CombineVectors(typeA_imm, typeB_imm);


//     }

//     return;
// }

int main() {
    const list<PokemonType> pTypes = ImportTypes();

    const vector<tuple<PokemonType,PokemonType>> typeCombos = ImportTypeCombos(pTypes);

    TeamGenerator gen;

    string bestTeam;
    double bestTeamScore = -1.0;

    if(!StateManager::load_state(fileName_state, bestTeam, bestTeamScore)) {
        cout << "Starting new generation..." << endl;
    }
    else {
        cout << "Resuming from saved state..." << endl;
    }
    
    int i = 0;
    list<PokemonType> uniqueTypes;
    while(true) {
        vector<tuple<PokemonType,PokemonType>> team = gen.next_team(typeCombos);

        // PrintTypeCombos(team);
        uniqueTypes = GetUniqueTypes(team, pTypes);
        // PrintTypes(uniqueTypes);

        double attScore = CalculateAttackingValue(uniqueTypes, typeCombos);
        // cout << "Attacking Value: " << attValue << endl;

        double defScore = CalculateDefenseValue(team, pTypes);
        // cout << "Defense Value: " << defValue << endl;

        double totValue = attScore - defScore;
        if(totValue > bestTeamScore) {
            bestTeam = TypeComboListToString(team);
            bestTeamScore = totValue;

            cout << "Team " << i << " is better!" << endl;
            cout << "\tTeam: " << bestTeam << endl;
            cout << "\tScore: " << bestTeamScore << endl;
            cout << "\tAttacking Score: " << attScore << endl;
            cout << "\tDefending Score: " << defScore << endl;

            StateManager::create_backup(fileName_state);
            StateManager::save_state(fileName_state, bestTeam, bestTeamScore);
        }

        ++i;
        if(i % 1000 == 0) {
            cout << "Processed " << i << " teams..." << endl;
        }
    }

    return 0;
}