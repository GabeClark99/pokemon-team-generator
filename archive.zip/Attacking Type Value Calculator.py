# type combo value source: https://www.reddit.com/r/pokemon/comments/4xawyi/i_created_a_table_listing_all_possible_type/
# type chart source: https://github.com/zonination/pokemon-chart/blob/master/chart.csv

import itertools

fileName_typeCombos = "defTypeComboValues.csv"
fileName_typeChart = "typeChart.csv"

class AttackingType:
    def __init__(self, name, supEff, nvEff, imm, neu):
        self.name = name
        self.supEff = supEff
        self.nvEff = nvEff
        self.imm = imm
        self.neu = neu
        self.atkScore = 0

class TypeCombo:
    def __init__(self, nameA, nameB, defScore):
        self.nameA = nameA
        self.nameB = nameB
        self.defScore = defScore

    def getComboName(self):
        return self.nameA + "/" + self.nameB

def ImportAttackingTypes():
    attackingTypes = []
    f = open(fileName_typeChart, "r")
    typeNames = f.readline().strip('\n').split(',')[1:]
    for line in f:
        lineData = line.strip('\n').split(',')
        typeName = lineData[0]
        lineWeak = []
        lineRes = []
        lineImm = []
        lineNeu = []

        i = 0
        for value in lineData[1:]:
            attackingType = typeNames[i].lower()

            match value:
                case "2":
                    lineWeak.append(attackingType)
                case "1":
                    lineNeu.append(attackingType)
                case "0.5":
                    lineRes.append(attackingType)
                case "0":
                    lineImm.append(attackingType)
                case _:
                    raise ValueError("Invalid type chart case: \"" + str(value) + "\"")

            i += 1

        attackingTypes.append(AttackingType(typeName, lineWeak, lineRes, lineImm, lineNeu))

    f.close()
    return attackingTypes

def ImportDefendingTypeCombos():
    defendingTypeCombos = []
    f = open(fileName_typeCombos, "r")
    for line in f:
        lineData = line.strip('\n').split(',')
        defendingTypeCombos.append(TypeCombo(lineData[0], lineData[1], lineData[2]))
    f.close()
    return defendingTypeCombos

def SetAttackingScores(attackingTypes, defendingTypeCombos):
    for attType in attackingTypes:
        print("attType.name=" + attType.name)
        totalScore = 0.0
        for defCombo in defendingTypeCombos:
            comboScore = 0.0
            # print("\t" + defCombo.nameA + "," + defCombo.nameB)

            if defCombo.nameA in attType.supEff:
                if defCombo.nameB in attType.supEff:
                    comboScore += 4
                elif defCombo.nameB in attType.neu:
                    comboScore += 2
                elif defCombo.nameB in attType.nvEff:
                    comboScore += 1
                elif defCombo.nameB in attType.imm:
                    comboScore = 0
                else:
                    raise Exception("No matching case for defCombo.nameB=\"" + defCombo.nameB + "\"")
                
            elif defCombo.nameA in attType.neu:
                if defCombo.nameB in attType.supEff:
                    comboScore += 2
                elif defCombo.nameB in attType.neu:
                    comboScore += 1
                elif defCombo.nameB in attType.nvEff:
                    comboScore += 0.5
                elif defCombo.nameB in attType.imm:
                    comboScore = 0
                else:
                    raise Exception("No matching case for defCombo.nameB=\"" + defCombo.nameB + "\"")
                
            elif defCombo.nameA in attType.nvEff:
                if defCombo.nameB in attType.supEff:
                    comboScore += 1
                elif defCombo.nameB in attType.neu:
                    comboScore += 0.5
                elif defCombo.nameB in attType.nvEff:
                    comboScore += 0.25
                elif defCombo.nameB in attType.imm:
                    comboScore = 0
                else:
                    raise Exception("No matching case for defCombo.nameB=\"" + defCombo.nameB + "\"")
                
            elif defCombo.nameA in attType.imm:
                comboScore = 0
            else:
                raise Exception("No matching case for defCombo.nameA=\"" + defCombo.nameA + "\"")

            # print("\tcomboScore=" + str(comboScore))
            totalScore += comboScore
        attType.atkScore = totalScore
        print("score=" + str(totalScore))
    return

def PrintPermutations(perms):
    i = 0
    for perm in perms:
        print("permutation: " + str(i))
        for t in perm:
            print("\t" + t.getComboName())
        i += 1
        if i >= 10: break

# import types and their values
attackingTypes = ImportAttackingTypes()
defendingTypeCombos = ImportDefendingTypeCombos()

# --- calculate value for attacking types ---
SetAttackingScores(attackingTypes, defendingTypeCombos)
