#include "data.h"
#include "generator.h"

int main() {
    initializeAllTypesMap();
    precomputeTypeEffectiveness();

    Generator g(typeCombos, potentialMembers, allTypes, true); // Pass true to use global types
    g.generate();

    return 0;
}