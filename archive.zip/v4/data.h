#pragma once

#include <unordered_map>
#include <string>
#include <vector>
#include <cstdint>

using std::pair;
using std::string;
using std::unordered_map;
using std::vector;

const size_t NO_TYPE = SIZE_MAX;

using TypeChart = unordered_map<size_t, unordered_map<size_t, double>>;
using TypeCombo = pair<size_t, size_t>; // stores pairs of indicies in allTypes

struct Pokemon {
    TypeCombo typeCombo;
    string ability;
    string name;
};

extern unordered_map<string, size_t> allTypesMap;
extern const vector<string> allTypes;
extern const TypeChart typeChart;
extern const vector<TypeCombo> typeCombos;
extern const vector<Pokemon> potentialMembers;

void initializeAllTypesMap();
void precomputeTypeEffectiveness();

double typeEffectiveness(
    const size_t& moveTypeIdx, 
    const TypeCombo& targetTcIdx,  
    const vector<string>& types,
    const vector<TypeCombo>& combos,
    const bool& useGlobalTypes,
    const string& ability
);

double getAbilityTypeModifier(const string& ability, size_t moveTypeIdx, const vector<string>& types);
