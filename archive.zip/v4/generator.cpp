#include <iostream>
#include <unordered_set>
#include <stack>
#include <thread>
#include "data.h"
#include "generator.h"

using std::cerr;
using std::chrono::duration;
using std::copy;
using std::begin;
using std::end;
using std::cout;
using std::endl;
using std::lock_guard;
using std::move;
using std::stack;
using std::string;
using std::thread;
using std::unordered_set;

void Generator::generate() {
    cout << "Starting team generation..." << endl;
    startTime_ = steady_clock::now();
    vector<thread> threads;
    for (size_t i = 0; i < thread::hardware_concurrency(); ++i) {
        threads.emplace_back(&Generator::worker, this, i);
    }
    for (auto& t : threads) {
        t.join();
    }
    printTopTeams();
    cout << "Generation completed in " << duration<double>(steady_clock::now() - startTime_).count() << " seconds." << endl;
}

void Generator::worker(size_t threadId) {
    // std::cout << "Worker thread " << threadId << " started." << std::endl;
    for (
        size_t i = threadId; 
        i < potentialMembers_.size() - 5; 
        i += thread::hardware_concurrency()
    ) buildTeam(i);
}

void Generator::buildTeam(size_t initialMemberIdx) {
    // std::cout << "buildTeam called for initialMemberIdx=" << initialMemberIdx << std::endl;
    struct StackFrame {
        vector<size_t> memberIndices;
        size_t nextIdx;   // next TypeCombo index to try
        bool usedTypes[18] = { false };
    };

    vector<size_t> memberIndices;
    memberIndices.push_back(initialMemberIdx);

    stack<StackFrame> dfsStack;
    StackFrame frame{memberIndices, 0};
    const auto& tc = potentialMembers_[initialMemberIdx].typeCombo;
    if (tc.first != NO_TYPE) frame.usedTypes[tc.first] = true;
    if (tc.second != NO_TYPE) frame.usedTypes[tc.second] = true;
    dfsStack.push(frame);

    // Progress updates
    if (memberIndices.size() == 1) {
        lock_guard<mutex> lock(progressMutex_);
        ++rootCombosVisited_;
        if (rootCombosVisited_ % 1 == 0 && rootCombosVisited_ > 12) {
            auto now = steady_clock::now();
            double elapsedSec = duration<double>(now - startTime_).count();

            double progress = static_cast<double>(rootCombosVisited_ - 1) / (potentialMembers_.size() - 5);
            double estimatedTotal = elapsedSec / progress;
            double remaining = estimatedTotal - elapsedSec;

            cout << "Progress: " << (progress * 100.0) << "%, "
                << "Elapsed: " << elapsedSec << "s, "
                << "Remaining: ~" << remaining << "s" << endl;
        }
    }

    while (!dfsStack.empty()) {
        auto& frame = dfsStack.top();
        // std::cout << "DFS stack size: " << dfsStack.size() << ", team size: " << frame.memberTcIndices.size() << ", nextIdx: " << frame.nextIdx << std::endl; //debug

        // made a full team. evaluate and add if better than current worst
        if (frame.memberIndices.size() == 6) {
            auto [off, def] = teamsManager.evaluateTeam(frame.memberIndices, types_);
            if (def > 0) teamsManager.tryAdd({frame.memberIndices, off, def});    // only try adding if the defensive score isn't terrible
            dfsStack.pop();
            continue;
        }

        bool foundNext = false;
        for (size_t i = frame.nextIdx; i < potentialMembers_.size(); ++i) {
            const auto& [t1, t2] = potentialMembers_[i].typeCombo;
            if ((t1 != NO_TYPE && frame.usedTypes[t1]) || (t2 != NO_TYPE && frame.usedTypes[t2])) continue;

            // Advance idx to next combo, copy the appended list of members, and push that frame
            frame.nextIdx = i + 1;
            vector<size_t> newIndices = frame.memberIndices;
            newIndices.push_back(i);
            StackFrame nextFrame;
            nextFrame.memberIndices = move(newIndices);
            nextFrame.nextIdx = i + 1;  // only allow further additions with higher indices
            copy(begin(frame.usedTypes), end(frame.usedTypes), begin(nextFrame.usedTypes)); // array copy
            if (t1 != NO_TYPE) nextFrame.usedTypes[t1] = true;
            if (t2 != NO_TYPE) nextFrame.usedTypes[t2] = true;
            dfsStack.push(nextFrame);
            foundNext = true;
            break;
        }

        if (!foundNext) dfsStack.pop(); // no more valid teams for this combo
    }
}

void Generator::printTopTeams() {
    const auto topTeams = teamsManager.getTopTeams();

    // Collect sorted names for each team
    vector<vector<string>> sortedNamesList;
    for (const auto& team : topTeams) {
        vector<string> names;
        for (size_t memberIdx : team.memberIndices) names.push_back(potentialMembers_[memberIdx].name);
        std::sort(names.begin(), names.end());
        sortedNamesList.push_back(move(names));
    }

    // Compute max width for each member column
    const size_t teamSize = sortedNamesList.empty() ? 0 : sortedNamesList[0].size();
    vector<size_t> colWidths(teamSize, 0);
    for (const auto& names : sortedNamesList) {
        for (size_t i = 0; i < names.size(); ++i) {
            if (names[i].size() > colWidths[i]) colWidths[i] = names[i].size();
        }
    }

    // Print teams with aligned columns
    for (size_t t = 0; t < topTeams.size(); ++t) {
        const auto& team = topTeams[t];
        cout << "(Off=" << team.offensiveValue << ", Def=" << team.defensiveValue << "): ";
        const auto& names = sortedNamesList[t];
        for (size_t i = 0; i < names.size(); ++i) {
            cout << names[i];
            if (i + 1 < names.size()) {
                // pad to colWidths[i] + 1 space
                cout << string(colWidths[i] - names[i].size() + 1, ' ');
            }
        }
        cout << endl;
    }
}

const vector<Team> Generator::getTopTeams() const {
    return teamsManager.getTopTeams();
}
