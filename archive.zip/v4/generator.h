#pragma once

#include <atomic>
#include "team.h"

using std::atomic;
using std::chrono::time_point;
using std::chrono::steady_clock;

class Generator {
public:
    Generator(
        const vector<TypeCombo>& combos, 
        const vector<Pokemon>& potentialMembers, 
        const vector<string>& types, 
        const bool& useGlobalTypes
    ): 
        typeCombos_(combos), 
        potentialMembers_(potentialMembers), 
        types_(types), 
        teamsManager(combos, potentialMembers, types, useGlobalTypes) 
    {}
    void generate();
    const vector<Team> getTopTeams() const;

private:
    TopTeamsManager teamsManager;
    vector<TypeCombo> typeCombos_;
    vector<Pokemon> potentialMembers_;
    vector<string> types_;
    atomic<size_t> rootCombosVisited_ = 0;
    time_point<steady_clock> startTime_;
    mutable mutex progressMutex_;

    void worker(size_t threadId);
    void buildTeam(size_t initialMemberTcIdx);
    bool conflictsWith(const vector<size_t>& memberIndices, const size_t candidateIdx) const;
    void printTopTeams();
};