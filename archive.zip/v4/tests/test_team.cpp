#include <catch2/catch_test_macros.hpp>
#include "team.h"
#include "test_helpers.h"

using std::distance;
using std::find;

TEST_CASE("Team comparison operator") {
    Team low    { {}, 1.0, 1.0};
    Team mid    { {}, 2.0, 0.5};
    Team high   { {}, 2.0, 2.0};

    SECTION("Team with higher offensiveValue is considered greater") {
        REQUIRE(mid > low);
    }

    SECTION("If offensiveValue is equal, team with higher defensiveValue is considered greater") {
        REQUIRE(high > mid);
    }

    SECTION("Team with both higher values is considered greater") {
        REQUIRE(high > low);
    }
}

TEST_CASE("TopTeamsManager maintains correct top 10") {
    initializeAllTypesMap();
    precomputeTypeEffectiveness();
    TopTeamsManager manager(typeCombos, potentialMembers, allTypes, true);

    SECTION("All accepted while under 10 teams") {
        for (int i=0; i < 5; ++i) {
            manager.tryAdd(Team{{size_t(i)}, double(i), 0.0});
        }
        auto result = manager.getTopTeams();

        REQUIRE(result.size() == 5);
        REQUIRE(result.front().offensiveValue == 4.0);
    }

    SECTION("Worse teams are rejected after reaching 10") {
        for (int i=0; i < 10; ++i) {
            manager.tryAdd(Team{{size_t(i)}, double(i + 1), 0.0});
        }
        manager.tryAdd(Team{{10}, 0.5, 0.0});
        auto result = manager.getTopTeams();

        REQUIRE(result.size() == 10);
        REQUIRE(result.back().offensiveValue == 1.0);
        REQUIRE(result.front().offensiveValue == 10.0);
    }

    SECTION("Better team replaces worst after reaching 10") {
        for (int i=0; i < 10; ++i) {
            manager.tryAdd(Team{{size_t(i)}, double(i), 0.0});
        }
        manager.tryAdd(Team{{10}, 100.0, 0.0});
        auto result = manager.getTopTeams();

        REQUIRE(result.size() == 10);
        REQUIRE(result.back().offensiveValue == 1.0);
        REQUIRE(result.front().offensiveValue == 100.0);
    }

    SECTION("Teams are returned in descending order") {
        for (int i=0; i < 10; ++i) {
            manager.tryAdd(Team{{size_t(i)}, double(i), 0.0});
        }
        auto result = manager.getTopTeams();

        for (size_t i = 1; i < result.size(); ++i) {
            REQUIRE(result[i - 1].offensiveValue >= result[i].offensiveValue);
        }
    }
}

TEST_CASE("TopTeamsManager evaluateTeam returns correct offense values") {
    initializeAllTypesMap();
    precomputeTypeEffectiveness();

    // One attacker, one defender
    SECTION("One attacker, one defender, super effective") {
        const vector<TypeCombo> typeCombos = { makeTypeCombo("ghost", "", allTypes) };
        const vector<Pokemon> potentialMembers = {{{makeTypeCombo("ghost", "", allTypes)}, "Ability1"}};
        TopTeamsManager manager(typeCombos, potentialMembers, allTypes, false);
        auto [offensive, defensive] = manager.evaluateTeam({0});
        REQUIRE(offensive == 1.0);
    }

    SECTION("One attacker, one defender, neutral") {
        const vector<TypeCombo> typeCombos = { makeTypeCombo("normal", "", allTypes) };
        const vector<Pokemon> potentialMembers = {{{makeTypeCombo("normal", "", allTypes)}, "Ability1"}};
        TopTeamsManager manager(typeCombos, potentialMembers, allTypes, false);
        auto [offensive, defensive] = manager.evaluateTeam({0});
        REQUIRE(offensive == 0.0);
    }

    SECTION("One attacker, one defender, neutral (cancel out)") {
        const vector<TypeCombo> typeCombos = { makeTypeCombo("fire", "water", allTypes) };
        const vector<Pokemon> potentialMembers = {{{makeTypeCombo("fire", "water", allTypes)}, "Ability1"}};
        TopTeamsManager manager(typeCombos, potentialMembers, allTypes, false);
        auto [offensive, defensive] = manager.evaluateTeam({0});
        REQUIRE(offensive == 0.0);
    }

    SECTION("One attacker, one defender, not very effective") {
        const vector<TypeCombo> typeCombos = { makeTypeCombo("fire", "", allTypes) };
        const vector<Pokemon> potentialMembers = {{{makeTypeCombo("fire", "", allTypes)}, "Ability1"}};
        TopTeamsManager manager(typeCombos, potentialMembers, allTypes, false);
        auto [offensive, defensive] = manager.evaluateTeam({0});
        REQUIRE(offensive == 0.0);
    }

    SECTION("One attacker, one defender, immune") {
        const vector<TypeCombo> typeCombos = { makeTypeCombo("ghost", "normal", allTypes) };
        const vector<Pokemon> potentialMembers = {{{makeTypeCombo("ghost", "normal", allTypes)}, "Ability1"}};
        TopTeamsManager manager(typeCombos, potentialMembers, allTypes, false);
        auto [offensive, defensive] = manager.evaluateTeam({0});
        REQUIRE(offensive == 0.0);
    }

    // One attacker, two defenders
    SECTION("One attacker, two defenders, super effective on both") {
        const vector<TypeCombo> typeCombos = { makeTypeCombo("ghost", "", allTypes), makeTypeCombo("psychic", "", allTypes) };
        const vector<Pokemon> potentialMembers = {
            {{makeTypeCombo("ghost", "", allTypes)}, "Ability1"}, 
            {{makeTypeCombo("psychic", "", allTypes)}, "Ability2"}};
        TopTeamsManager manager(typeCombos, potentialMembers, allTypes, false);
        auto [offensive, defensive] = manager.evaluateTeam({0});
        REQUIRE(offensive == 2.0);
    }

    SECTION("One attacker, two defenders, super effective on one") {
        const vector<TypeCombo> typeCombos = { makeTypeCombo("ghost", "", allTypes), makeTypeCombo("normal", "", allTypes) };
        const vector<Pokemon> potentialMembers = {{{makeTypeCombo("ghost", "", allTypes)}, "Ability1"}};
        TopTeamsManager manager(typeCombos, potentialMembers, allTypes, false);
        auto [offensive, defensive] = manager.evaluateTeam({0});
        REQUIRE(offensive == 1.0);
    }

    SECTION("One attacker, two defenders, super effective on neither") {
        const vector<TypeCombo> typeCombos = { makeTypeCombo("fire", "", allTypes), makeTypeCombo("normal", "", allTypes) };
        const vector<Pokemon> potentialMembers = {{{makeTypeCombo("fire", "", allTypes)}, "Ability1"}};
        TopTeamsManager manager(typeCombos, potentialMembers, allTypes, false);
        auto [offensive, defensive] = manager.evaluateTeam({0});
        REQUIRE(offensive == 0.0);
    }

    // Two attackers, two defenders
    SECTION("Two attackers, two defenders, both super effective on both") {
        const vector<TypeCombo> typeCombos = { makeTypeCombo("ghost", "", allTypes), makeTypeCombo("ghost", "", allTypes) };
        const vector<Pokemon> potentialMembers = {
            {{makeTypeCombo("ghost", "", allTypes)}, "Ability1"},
            {{makeTypeCombo("ghost", "", allTypes)}, "Ability2"}
        };
        TopTeamsManager manager(typeCombos, potentialMembers, allTypes, false);
        auto [offensive, defensive] = manager.evaluateTeam({0, 1});
        REQUIRE(offensive == 2.0);
    }

    SECTION("Two attackers, two defenders, one super effective on both") {
        const vector<TypeCombo> typeCombos = { makeTypeCombo("fighting", "dark", allTypes), makeTypeCombo("ice", "", allTypes) };
        const vector<Pokemon> potentialMembers = {
            {{makeTypeCombo("fighting", "dark", allTypes)}, "Ability1"},
            {{makeTypeCombo("ice", "", allTypes)}, "Ability2"}
        };
        TopTeamsManager manager(typeCombos, potentialMembers, allTypes, false);
        auto [offensive, defensive] = manager.evaluateTeam({0, 1});
        REQUIRE(offensive == 2.0);
    }

    SECTION("Two attackers, two defenders, both super effective on different") {
        const vector<TypeCombo> typeCombos = { makeTypeCombo("water", "psychic", allTypes), makeTypeCombo("fire", "dark", allTypes) };
        const vector<Pokemon> potentialMembers = {
            {{makeTypeCombo("water", "psychic", allTypes)}, "Ability1"},
            {{makeTypeCombo("fire", "dark", allTypes)}, "Ability2"}
        };
        TopTeamsManager manager(typeCombos, potentialMembers, allTypes, false);
        auto [offensive, defensive] = manager.evaluateTeam({0, 1});
        REQUIRE(offensive == 2.0);
    }

    SECTION("Two attackers, two defenders, one super effective on one") {
        const vector<TypeCombo> typeCombos = { makeTypeCombo("water", "", allTypes), makeTypeCombo("fire", "", allTypes) };
        const vector<Pokemon> potentialMembers = {
            {{makeTypeCombo("water", "", allTypes)}, "Ability1"},
            {{makeTypeCombo("fire", "", allTypes)}, "Ability2"}
        };
        TopTeamsManager manager(typeCombos, potentialMembers, allTypes, false);
        auto [offensive, defensive] = manager.evaluateTeam({0, 1});
        REQUIRE(offensive == 1.0);
    }

    SECTION("Two attackers, two defenders, neither super effective on any") {
        const vector<TypeCombo> typeCombos = { makeTypeCombo("normal", "", allTypes), makeTypeCombo("normal", "", allTypes) };
        const vector<Pokemon> potentialMembers = {
            {{makeTypeCombo("normal", "", allTypes)}, "Ability1"},
            {{makeTypeCombo("normal", "", allTypes)}, "Ability2"}
        };
        TopTeamsManager manager(typeCombos, potentialMembers, allTypes, false);
        auto [offensive, defensive] = manager.evaluateTeam({0, 1});
        REQUIRE(offensive == 0.0);
    }
}

TEST_CASE("TopTeamsManager evaluateTeam returns correct defense values") {
    initializeAllTypesMap();
    precomputeTypeEffectiveness();
    
    SECTION("Two attacking types, single type defender, one immune one neutral") {
        const vector<string> types = {"ground", "flying"};
        const vector<TypeCombo> typeCombos = {
            makeTypeCombo("ground", "", types),
            makeTypeCombo("flying", "", types)
        };
        const vector<Pokemon> potentialMembers = {{{makeTypeCombo("flying", "", types)}, "Ability1"}};
        TopTeamsManager manager(typeCombos, potentialMembers, types, false);
        auto [offensive, defensive] = manager.evaluateTeam({0});
        REQUIRE(defensive == 2.0);
    }

    SECTION("Two attacking types, single type defender, both neutral") {
        const vector<string> types = {"normal", "flying"};
        const vector<TypeCombo> typeCombos = {
            makeTypeCombo("normal", "", types),
            makeTypeCombo("flying", "", types)
        };
        const vector<Pokemon> potentialMembers = {{{makeTypeCombo("flying", "", types)}, "Ability1"}};
        TopTeamsManager manager(typeCombos, potentialMembers, types, false);
        auto [offensive, defensive] = manager.evaluateTeam({0});
        REQUIRE(defensive == 0.0);
    }

    SECTION("Two attacking types, single type defender, one neutral one resist") {
        const vector<string> types = {"bug", "flying"};
        const vector<TypeCombo> typeCombos = {
            makeTypeCombo("bug", "", types),
            makeTypeCombo("flying", "", types)
        };
        const vector<Pokemon> potentialMembers = {{{makeTypeCombo("flying", "", types)}, "Ability1"}};
        TopTeamsManager manager(typeCombos, potentialMembers, types, false);
        auto [offensive, defensive] = manager.evaluateTeam({0});
        REQUIRE(defensive == 1.0);
    }

    SECTION("Two attacking types, single type defender, resist both") {
        const vector<string> types = {"bug", "fire"};
        const vector<TypeCombo> typeCombos = {
            makeTypeCombo("bug", "", types),
            makeTypeCombo("fire", "", types)
        };
        const vector<Pokemon> potentialMembers = {{{makeTypeCombo("fire", "", types)}, "Ability1"}};
        TopTeamsManager manager(typeCombos, potentialMembers, types, false);
        auto [offensive, defensive] = manager.evaluateTeam({0});
        REQUIRE(defensive == 2.0);
    }

    SECTION("Two attacking types, single type defender, one neutral one weak") {
        const vector<string> types = {"electric", "flying"};
        const vector<TypeCombo> typeCombos = {
            makeTypeCombo("electric", "", types),
            makeTypeCombo("flying", "", types)
        };
        const vector<Pokemon> potentialMembers = {{{makeTypeCombo("flying", "", types)}, "Ability1"}};
        TopTeamsManager manager(typeCombos, potentialMembers, types, false);
        auto [offensive, defensive] = manager.evaluateTeam({0});
        REQUIRE(defensive == -1.0);
    }

    SECTION("Two attacking types, single type defender, both weak") {
        const vector<string> types = {"ice", "dragon"};
        const vector<TypeCombo> typeCombos = {
            makeTypeCombo("ice", "", types),
            makeTypeCombo("dragon", "", types)
        };
        const vector<Pokemon> potentialMembers = {{{makeTypeCombo("dragon", "", types)}, "Ability1"}};
        TopTeamsManager manager(typeCombos, potentialMembers, types, false);
        auto [offensive, defensive] = manager.evaluateTeam({0});
        REQUIRE(defensive == -2.0);
    }

    SECTION("Two attacking types, dual type defender, one double weak one resist") {
        const vector<string> types = {"ghost", "psychic"};
        const vector<TypeCombo> typeCombos = {
            makeTypeCombo("ghost", "", types),
            makeTypeCombo("psychic", "", types),
            makeTypeCombo("ghost", "psychic", types)
        };
        const vector<Pokemon> potentialMembers = {{{makeTypeCombo("ghost", "psychic", types)}, "Ability1"}};
        TopTeamsManager manager(typeCombos, potentialMembers, types, false);
        auto [offensive, defensive] = manager.evaluateTeam({0});
        REQUIRE(defensive == -2.0 + 1.0); // -4 for two 2x weaknesses, +1 for resist psychic
    }

    SECTION("Two attacking types, dual type defender, one double resist one neutral") {
        const vector<string> types = {"ice", "fire"};
        const vector<TypeCombo> typeCombos = {
            makeTypeCombo("ice", "", types),
            makeTypeCombo("fire", "", types),
            makeTypeCombo("fire", "fire", types)
        };
        const vector<Pokemon> potentialMembers = {{{makeTypeCombo("ice", "fire", types)}, "Ability1"}};
        TopTeamsManager manager(typeCombos, potentialMembers, types, false);
        auto [offensive, defensive] = manager.evaluateTeam({0});
        REQUIRE(defensive == 2.0); // +2 for 0.25 resist, +0 for neutral (cancel out)
    }

    SECTION("One defender, immunity ability") {
        const vector<Pokemon> potentialMembers = {
            {{makeTypeCombo("normal", "", allTypes)}, "Levitate"},
        };
        TopTeamsManager manager(typeCombos, potentialMembers, allTypes, true);
        auto [offensive, defensive] = manager.evaluateTeam({0, 1});
        REQUIRE(defensive == 3.0); // +2 for levitate
    }

    SECTION("Two defenders, both have immunity ability") {
        const vector<Pokemon> potentialMembers = {
            {{makeTypeCombo("normal", "", allTypes)}, "Levitate"},
            {{makeTypeCombo("normal", "", allTypes)}, "Levitate"}
        };
        TopTeamsManager manager(typeCombos, potentialMembers, allTypes, true);
        auto [offensive, defensive] = manager.evaluateTeam({0, 1});
        REQUIRE(getAbilityTypeModifier("Levitate", getTypeIndex("ground", allTypes), allTypes) == 0.0);
        REQUIRE(defensive == 2.0); // +2 for levitate should only be added once
    }

    SECTION("Specific case: Mamoswine") {
        // const vector<string> types = allTypes;
        // const vector<TypeCombo> combos = typeCombos;
        const vector<Pokemon> potentialMembers = {{{makeTypeCombo("ground", "ice", allTypes)}, "Thick Fat"}};
        TopTeamsManager manager(typeCombos, potentialMembers, allTypes, false);

        auto [offensive, defensive] = manager.evaluateTeam({0});
        REQUIRE(defensive == 0.0);
    }
    
    SECTION("Specific case: Misdreavus") {
        const vector<string> types = allTypes;
        const vector<TypeCombo> combos = typeCombos;
        const vector<Pokemon> potentialMembers = {{{makeTypeCombo("ghost", "fairy", types)}, "Levitate"}};
        TopTeamsManager manager(combos, potentialMembers, types, false);

        auto [offensive, defensive] = manager.evaluateTeam({0});
        REQUIRE(defensive == 8.0);
    }

    // SECTION("Specific case: top team #1") {
    //     // (Off=109, Def=11): Houndoom  Lucario   Mamoswine Mismagius Roserade   Rotom-Wash
    //     // calculated by hand as Def=10
    //     const vector<string> types = allTypes;
    //     const vector<TypeCombo> combos = typeCombos;
    //     const vector<Pokemon> potentialMembers = {
    //         {{makeTypeCombo("fire", "dark", types)},        "",             "houndoom"},
    //         {{makeTypeCombo("fighting", "steel", types)},   "",             "lucario"},
    //         {{makeTypeCombo("ice", "ground", types)},       "Thick Fat",    "mamoswine"},
    //         {{makeTypeCombo("ghost", "psychic", types)},    "Levitate",     "mismagius"},
    //         {{makeTypeCombo("grass", "poison", types)},     "",             "roserade"},
    //         {{makeTypeCombo("electric", "water", types)},   "Levitate",     "rotom-wash"}
    //     };
    // }
}