#include <catch2/catch_test_macros.hpp>
#include <catch2/catch_approx.hpp>
#include "data.h"
#include "test_helpers.h"

TEST_CASE("typeEffectiveness returns correct multipliers") {
    initializeAllTypesMap();
    precomputeTypeEffectiveness();

    SECTION("Single-type targets") {
        REQUIRE(typeEffectiveness(getTypeIndex("fire", allTypes), TypeCombo{getTypeIndex("grass", allTypes), NO_TYPE}, allTypes, typeCombos, true, "") == Catch::Approx(2.0));
        REQUIRE(typeEffectiveness(getTypeIndex("water", allTypes), TypeCombo{getTypeIndex("grass", allTypes), NO_TYPE}, allTypes, typeCombos, true, "") == Catch::Approx(0.5));
        REQUIRE(typeEffectiveness(getTypeIndex("normal", allTypes), TypeCombo{getTypeIndex("fire", allTypes), NO_TYPE}, allTypes, typeCombos, true, "") == Catch::Approx(1.0));
        REQUIRE(typeEffectiveness(getTypeIndex("normal", allTypes), TypeCombo{getTypeIndex("ghost", allTypes), NO_TYPE}, allTypes, typeCombos, true, "") == Catch::Approx(0.0));
        REQUIRE(typeEffectiveness(getTypeIndex("ghost", allTypes), TypeCombo{getTypeIndex("normal", allTypes), NO_TYPE}, allTypes, typeCombos, true, "") == Catch::Approx(0.0));
    }

    SECTION("Dual-type targets") {
        REQUIRE(typeEffectiveness(getTypeIndex("fire", allTypes), TypeCombo{getTypeIndex("bug", allTypes), getTypeIndex("steel", allTypes)}, allTypes, typeCombos, true, "") == Catch::Approx(4.0));
        REQUIRE(typeEffectiveness(getTypeIndex("fire", allTypes), TypeCombo{getTypeIndex("grass", allTypes), getTypeIndex("fire", allTypes)}, allTypes, typeCombos, true, "") == Catch::Approx(1.0));
        REQUIRE(typeEffectiveness(getTypeIndex("fire", allTypes), TypeCombo{getTypeIndex("grass", allTypes), getTypeIndex("normal", allTypes)}, allTypes, typeCombos, true, "") == Catch::Approx(2.0));
        REQUIRE(typeEffectiveness(getTypeIndex("fire", allTypes), TypeCombo{getTypeIndex("dragon", allTypes), getTypeIndex("water", allTypes)}, allTypes, typeCombos, true, "") == Catch::Approx(0.25));
    }

    SECTION("Immunities") {
        REQUIRE(typeEffectiveness(getTypeIndex("normal", allTypes), TypeCombo{getTypeIndex("ghost", allTypes), NO_TYPE}, allTypes, typeCombos, true, "") == Catch::Approx(0.0));
        REQUIRE(typeEffectiveness(getTypeIndex("ghost", allTypes), TypeCombo{getTypeIndex("normal", allTypes), NO_TYPE}, allTypes, typeCombos, true, "") == Catch::Approx(0.0));
        REQUIRE(typeEffectiveness(getTypeIndex("dragon", allTypes), TypeCombo{getTypeIndex("fairy", allTypes), NO_TYPE}, allTypes, typeCombos, true, "") == Catch::Approx(0.0));
        REQUIRE(typeEffectiveness(getTypeIndex("ground", allTypes), TypeCombo{getTypeIndex("flying", allTypes), NO_TYPE}, allTypes, typeCombos, true, "") == Catch::Approx(0.0));
        REQUIRE(typeEffectiveness(getTypeIndex("electric", allTypes), TypeCombo{getTypeIndex("ground", allTypes), NO_TYPE}, allTypes, typeCombos, true, "") == Catch::Approx(0.0));
    }

    SECTION("Fallback/default behavior") {
        REQUIRE(typeEffectiveness(getTypeIndex("???", allTypes), TypeCombo{getTypeIndex("water", allTypes), getTypeIndex("electric", allTypes)}, allTypes, typeCombos, true, "") == Catch::Approx(1.0));
        REQUIRE(typeEffectiveness(getTypeIndex("normal", allTypes), TypeCombo{NO_TYPE, NO_TYPE}, allTypes, typeCombos, true, "") == Catch::Approx(1.0));
    }

    SECTION("Custom types list") {
        vector<string> customTypes = {"fire", "grass", "water"};
        size_t fireIdx = 0; // customTypes[0] = "fire"
        size_t grassIdx = 1; // customTypes[1] = "grass"
        size_t waterIdx = 2; // customTypes[2] = "water"
        REQUIRE(typeEffectiveness(fireIdx, TypeCombo{grassIdx, NO_TYPE}, customTypes, typeCombos, false, "") == Catch::Approx(2.0));
        REQUIRE(typeEffectiveness(waterIdx, TypeCombo{grassIdx, NO_TYPE}, customTypes, typeCombos, false, "") == Catch::Approx(0.5));
        REQUIRE(typeEffectiveness(fireIdx, TypeCombo{waterIdx, NO_TYPE}, customTypes, typeCombos, false, "") == Catch::Approx(0.5));
        REQUIRE(typeEffectiveness(fireIdx, TypeCombo{fireIdx, NO_TYPE}, customTypes, typeCombos, false, "") == Catch::Approx(0.5));
        REQUIRE(typeEffectiveness(fireIdx, TypeCombo{grassIdx, waterIdx}, customTypes, typeCombos, false, "") == Catch::Approx(1.0));
    }
}

TEST_CASE("getAbilityTypeModifier returns correct multipliers") {
    SECTION("Immunities") {
        REQUIRE(getAbilityTypeModifier("Levitate", getTypeIndex("ground", allTypes), allTypes) == Catch::Approx(0.0));
        REQUIRE(getAbilityTypeModifier("Volt Absorb", getTypeIndex("electric", allTypes), allTypes) == Catch::Approx(0.0));
        REQUIRE(getAbilityTypeModifier("Motor Drive", getTypeIndex("electric", allTypes), allTypes) == Catch::Approx(0.0));
        REQUIRE(getAbilityTypeModifier("Lightning Rod", getTypeIndex("electric", allTypes), allTypes) == Catch::Approx(0.0));
        REQUIRE(getAbilityTypeModifier("Water Absorb", getTypeIndex("water", allTypes), allTypes) == Catch::Approx(0.0));
        REQUIRE(getAbilityTypeModifier("Flash Fire", getTypeIndex("fire", allTypes), allTypes) == Catch::Approx(0.0));
    }

    SECTION("Resistances") {
        REQUIRE(getAbilityTypeModifier("Thick Fat", getTypeIndex("fire", allTypes), allTypes) == Catch::Approx(0.5));
        REQUIRE(getAbilityTypeModifier("Thick Fat", getTypeIndex("ice", allTypes), allTypes) == Catch::Approx(0.5));
    }

    SECTION("Default case") {
        REQUIRE(getAbilityTypeModifier("", getTypeIndex("fire", allTypes), allTypes) == Catch::Approx(1.0));
        REQUIRE(getAbilityTypeModifier("Unknown Ability", getTypeIndex("fire", allTypes), allTypes) == Catch::Approx(1.0));
    }

}

TEST_CASE("correct multipliers are calculated when getAbilityTypeModifer and typeEffectiveness are used in conjunction") {
    initializeAllTypesMap();
    precomputeTypeEffectiveness();

    SECTION("Abilities countering type effectiveness") {
        double mult = typeEffectiveness(getTypeIndex("ground", allTypes), TypeCombo{getTypeIndex("electric", allTypes), NO_TYPE}, allTypes, typeCombos, true, "Levitate");
        REQUIRE(mult == Catch::Approx(0.0)); // Levitate should nullify electric's effectiveness against ground

        mult = typeEffectiveness(getTypeIndex("fire", allTypes), TypeCombo{getTypeIndex("ice", allTypes), NO_TYPE}, allTypes, typeCombos, true, "Thick Fat");
        REQUIRE(mult == Catch::Approx(1.0)); // Thick Fat should neutralize fire's effectiveness against ice

        mult = typeEffectiveness(getTypeIndex("ice", allTypes), TypeCombo{getTypeIndex("ice", allTypes), getTypeIndex("ground", allTypes)}, allTypes, typeCombos, true, "Thick Fat");
        REQUIRE(mult == Catch::Approx(0.5)); // Thick Fat should reduce ice's effectiveness from neutral to resist
    }
}

TEST_CASE("specific cases") {
    initializeAllTypesMap();
    precomputeTypeEffectiveness();

    SECTION("Mamoswine") {
        Pokemon mamoswine = {{5, 8}, "Thick Fat", "Mamoswine"};
        REQUIRE(typeEffectiveness(getTypeIndex("normal", allTypes), mamoswine.typeCombo, allTypes, typeCombos, true, mamoswine.ability) == Catch::Approx(1.0));
        REQUIRE(typeEffectiveness(getTypeIndex("fire", allTypes), mamoswine.typeCombo, allTypes, typeCombos, true, mamoswine.ability) == Catch::Approx(1.0));
        REQUIRE(typeEffectiveness(getTypeIndex("water", allTypes), mamoswine.typeCombo, allTypes, typeCombos, true, mamoswine.ability) == Catch::Approx(2.0));
        REQUIRE(typeEffectiveness(getTypeIndex("electric", allTypes), mamoswine.typeCombo, allTypes, typeCombos, true, mamoswine.ability) == Catch::Approx(0.0));
        REQUIRE(typeEffectiveness(getTypeIndex("grass", allTypes), mamoswine.typeCombo, allTypes, typeCombos, true, mamoswine.ability) == Catch::Approx(2.0));
        REQUIRE(typeEffectiveness(getTypeIndex("ice", allTypes), mamoswine.typeCombo, allTypes, typeCombos, true, mamoswine.ability) == Catch::Approx(0.5));
        REQUIRE(typeEffectiveness(getTypeIndex("fighting", allTypes), mamoswine.typeCombo, allTypes, typeCombos, true, mamoswine.ability) == Catch::Approx(2.0));
        REQUIRE(typeEffectiveness(getTypeIndex("poison", allTypes), mamoswine.typeCombo, allTypes, typeCombos, true, mamoswine.ability) == Catch::Approx(0.5));
        REQUIRE(typeEffectiveness(getTypeIndex("ground", allTypes), mamoswine.typeCombo, allTypes, typeCombos, true, mamoswine.ability) == Catch::Approx(1.0));
        REQUIRE(typeEffectiveness(getTypeIndex("flying", allTypes), mamoswine.typeCombo, allTypes, typeCombos, true, mamoswine.ability) == Catch::Approx(1.0));
        REQUIRE(typeEffectiveness(getTypeIndex("psychic", allTypes), mamoswine.typeCombo, allTypes, typeCombos, true, mamoswine.ability) == Catch::Approx(1.0));
        REQUIRE(typeEffectiveness(getTypeIndex("bug", allTypes), mamoswine.typeCombo, allTypes, typeCombos, true, mamoswine.ability) == Catch::Approx(1.0));
        REQUIRE(typeEffectiveness(getTypeIndex("rock", allTypes), mamoswine.typeCombo, allTypes, typeCombos, true, mamoswine.ability) == Catch::Approx(1.0));
        REQUIRE(typeEffectiveness(getTypeIndex("ghost", allTypes), mamoswine.typeCombo, allTypes, typeCombos, true, mamoswine.ability) == Catch::Approx(1.0));
        REQUIRE(typeEffectiveness(getTypeIndex("dragon", allTypes), mamoswine.typeCombo, allTypes, typeCombos, true, mamoswine.ability) == Catch::Approx(1.0));
        REQUIRE(typeEffectiveness(getTypeIndex("dark", allTypes), mamoswine.typeCombo, allTypes, typeCombos, true, mamoswine.ability) == Catch::Approx(1.0));
        REQUIRE(typeEffectiveness(getTypeIndex("steel", allTypes), mamoswine.typeCombo, allTypes, typeCombos, true, mamoswine.ability) == Catch::Approx(2.0));
        REQUIRE(typeEffectiveness(getTypeIndex("fairy", allTypes), mamoswine.typeCombo, allTypes, typeCombos, true, mamoswine.ability) == Catch::Approx(1.0));
    }

    // todo: rest of weird cases
}