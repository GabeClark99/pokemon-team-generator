#pragma once

#include <algorithm>
#include <string>
#include "data.h"

inline size_t getTypeIndex(const string& typeName, const vector<string>& types) {
	if (typeName.empty()) return NO_TYPE;

	auto it = find(types.begin(), types.end(), typeName);
	if (it != types.end()) return distance(types.begin(), it);
	return NO_TYPE;
}

inline TypeCombo makeTypeCombo(const string& type1, const string& type2, const vector<string>& types) {
	return TypeCombo{getTypeIndex(type1, types), getTypeIndex(type2, types)};
}
