#include <catch2/catch_test_macros.hpp>
#include <set>
#include "generator.h"
#include "test_helpers.h"

using std::set;
using std::string;

TEST_CASE("Generator generates valid 6-member teams with no type overlap") {
    initializeAllTypesMap();
    precomputeTypeEffectiveness();
    
    const vector<Pokemon> potentialMembers = {
        {{makeTypeCombo("fire", "fairy", allTypes)}, "Ability1"},
        {{makeTypeCombo("water", "dragon", allTypes)}, "Ability2"},
        {{makeTypeCombo("rock", "dark", allTypes)}, "Ability3"},
        {{makeTypeCombo("fighting", "steel", allTypes)}, "Ability4"},
        {{makeTypeCombo("ice", "ground", allTypes)}, "Ability5"},
        {{makeTypeCombo("electric", "ghost", allTypes)}, "Ability6"}
    };

    Generator g(typeCombos, potentialMembers, allTypes, false);

    g.generate();

    const auto& teams = g.getTopTeams();
    REQUIRE_FALSE(teams.empty());

    for (const auto& team : teams) {
        if (team.memberIndices.size() == 6) {
            set<size_t> seen;
            for (const auto& memberIdx : team.memberIndices) {
                const auto& [typeIdx1, typeIdx2] = potentialMembers[memberIdx].typeCombo;
                if (typeIdx1 != NO_TYPE) {
                    REQUIRE(seen.count(typeIdx1) == 0);
                    seen.insert(typeIdx1);
                }
                if (typeIdx2 != NO_TYPE) {
                    REQUIRE(seen.count(typeIdx2) == 0);
                    seen.insert(typeIdx2);
                }
            }
        } else {
            FAIL_CHECK("Unexpected incomplete team with " << team.memberIndices.size() << " members");
        }
    }
}
