#pragma once

#include <algorithm>
#include <mutex>
#include <queue>
#include <string>
#include <unordered_set>
#include <vector>
#include "data.h"

using std::greater;
using std::mutex;
using std::pair;
using std::priority_queue;
using std::string;
using std::tie;
using std::unordered_set;
using std::vector;

struct Team {
    vector<size_t> memberIndices; // indices into potentialMembers
    double offensiveValue;
    double defensiveValue;

    // prioritize offensive over defensive
    bool operator>(const Team& other) const {
        if (offensiveValue > other.offensiveValue) return true;
        if (offensiveValue == other.offensiveValue) return defensiveValue > other.defensiveValue;
        return false;
    }

    // Print team members sorted alphabetically by name (no-op, see Generator::printTopTeams for aligned output)
    void printTeam(const vector<TypeCombo>& combos, const vector<string>& types, const vector<Pokemon>& members) const;
};

class TopTeamsManager {
public:
    TopTeamsManager(
        const vector<TypeCombo>& combos, 
        const vector<Pokemon>& potentialMembers,
        const vector<string>& types, 
        const bool& useGlobalTypes
    ): 
        combos_(combos), 
        potentialMembers_(potentialMembers),
        types_(types), 
        useGlobalTypes_(useGlobalTypes) 
    {};
    void tryAdd(const Team& t);
    const vector<Team> getTopTeams() const;
    const pair<double, double> evaluateTeam(const vector<size_t>& memberTypeComboIndices);

private:
    priority_queue<Team, vector<Team>, greater<Team>> heap_;
    mutable mutex mtx_;
    vector<TypeCombo> combos_;
    vector<Pokemon> potentialMembers_;
    vector<string> types_;
    static constexpr size_t maxSize_ = 10;
    const bool useGlobalTypes_;
    unordered_set<string> teamSignatures_;
    string canonicalSignature(const vector<size_t>& memberTcIndices) const;
};
