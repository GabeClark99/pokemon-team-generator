import requests
from bs4 import BeautifulSoup

URL = "https://pokemondb.net/pokedex/national"

response = requests.get(URL)
soup = BeautifulSoup(response.text, "html.parser")

output = []
seen = set()

# The page is structured with headings (h2) for generations and infocards for Pokémon
main_content = soup.select_one("main")
if not main_content:
    main_content = soup  # fallback

for elem in main_content.find_all(["h2", "div"], recursive=True):
    if elem.name == "h2":
        title = elem.get_text(strip=True)
        output.append(f"\n{title}\n")
    elif elem.name == "div" and "infocard" in elem.get("class", []):
        type_tags = elem.select(".itype")
        types = tuple(sorted([t.text.strip().lower() for t in type_tags]))
        if types and types not in seen:
            output.append("{" + ", ".join(f'\"{t}\"' for t in types) + "}")
            seen.add(types)

print("Unique Pokémon type combinations (with section titles):")
for line in output:
    print(line)
