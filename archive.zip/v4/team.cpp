#include "team.h"

#include <iostream>
#include <unordered_set>
#include "data.h"
#include "team.h"

using std::cerr;
using std::cout;
using std::endl;
using std::lock_guard;
using std::reverse;
using std::unordered_set;

string TopTeamsManager::canonicalSignature(const vector<size_t>& memberIndices) const {
    // get string signature for a team independent of order
    vector<size_t> sortedIndices = memberIndices;
    sort(sortedIndices.begin(), sortedIndices.end());
    string sig;
    for (size_t idx : sortedIndices) {
        sig += std::to_string(idx) + ",";
    }
    return sig;
}

void Team::printTeam(const vector<TypeCombo>& teamCombos, const vector<string>& types, const vector<Pokemon>& members) const {
    // This function is now a no-op; see Generator::printTopTeams for new vertical alignment logic.
}

void TopTeamsManager::tryAdd(const Team& t) {
    lock_guard<mutex> lock(mtx_);
    std::string sig = canonicalSignature(t.memberIndices); // compute canonical signature (sorted member indices)
    if (teamSignatures_.count(sig)) return; // this team is a permutation of one we already have

    if (heap_.size() < maxSize_) {
        heap_.push(t);
        teamSignatures_.insert(sig);
    } else if (t > heap_.top()) {
        string popSig = canonicalSignature(heap_.top().memberIndices);

        heap_.pop();
        teamSignatures_.erase(popSig);

        heap_.push(t);
        teamSignatures_.insert(sig);
    }
}

const vector<Team> TopTeamsManager::getTopTeams() const {
    lock_guard<mutex> lock(mtx_);
    vector<Team> result;
    auto heapCopy = heap_;  // copy to avoid mutating original
    while (!heapCopy.empty()) {
        result.push_back(heapCopy.top());
        heapCopy.pop();
    }

    reverse(result.begin(), result.end());
    return result;
}

const pair<double, double> TopTeamsManager::evaluateTeam(const vector<size_t>& memberIndices) {
    unordered_set<size_t> hitIndexes; // indexes of combos_ we can hit SE
    for (const auto& attackerIdx : memberIndices) {
        const auto& [atkTypeIdx1, atkTypeIdx2] = potentialMembers_[attackerIdx].typeCombo;
        for (size_t i = 0; i < combos_.size(); ++i) {
            const auto& defTcIdx = combos_[i];
            bool isSuper = false;
            if (atkTypeIdx1 != NO_TYPE && typeEffectiveness(atkTypeIdx1, defTcIdx, types_, combos_, useGlobalTypes_, "") > 1.0) isSuper = true;
            if (atkTypeIdx2 != NO_TYPE && typeEffectiveness(atkTypeIdx2, defTcIdx, types_, combos_, useGlobalTypes_, "") > 1.0) isSuper = true;
            if (isSuper) hitIndexes.insert(i);
        }
    }

    double offensiveValue = static_cast<double>(hitIndexes.size());

    // Defensive value calculation
    // For each attacking type: if the result is a 0.5 resistance, the defensive value will be increased by one point.
    // If it's a 0.25 resistance, it'll be increased by two. 
    // An immunity (0.0) will add two points.
    // For each 2.0 weakness (does not have to be unique), subtract a point. 
    // For each 4.0 weakness, subtract 2.
    double defensiveValue = 0.0;
    for (size_t attackTypeIdx = 0; attackTypeIdx < types_.size(); ++attackTypeIdx) {
        bool hasImmunity = false;
        bool hasResist_05 = false;
        bool hasResist_025 = false;
        int weakCount_2 = 0;
        int weakCount_4 = 0;

        // For each team member, check their resistance to this type
        for (size_t memberIdx : memberIndices) {
            const auto& memberCombo = potentialMembers_[memberIdx].typeCombo;
            const auto& memberAbility = potentialMembers_[memberIdx].ability;
            double eff = typeEffectiveness(attackTypeIdx, memberCombo, types_, combos_, useGlobalTypes_, memberAbility);
            // std::cout<<types_[attackTypeIdx]<<" vs "<<memberTcIdx<<": "<<eff<<endl; // debug
            if (eff == 0.0) {
                hasImmunity = true;
            } else if (eff == 0.25) {
                hasResist_025 = true;
            } else if (eff == 0.5) {
                hasResist_05 = true;
            } else if (eff == 2.0) {
                weakCount_2++;
            } else if (eff == 4.0) {
                weakCount_4++;
            } else if (eff != 1.0){
                cerr << "Unexpected effectiveness value: " << eff 
                << " for type: " << attackTypeIdx 
                << " against defender: " << memberIdx 
                << endl;
            }
        }

        // Apply scoring rules
        if (hasImmunity || hasResist_025) defensiveValue += 2;
        else if (hasResist_05) defensiveValue += 1;
        defensiveValue -= weakCount_2;
        defensiveValue -= weakCount_4 * 2;
    }

    return {offensiveValue, defensiveValue};
}