#include "data.h"
#include <algorithm>
#include <array>
#include <iostream>

using std::array;
using std::cerr;
using std::endl;

constexpr size_t NUM_TYPES = 18;

unordered_map<string, size_t> allTypesMap;
array<array<array<double, NUM_TYPES + 1>, NUM_TYPES + 1>, NUM_TYPES> precomputedTypeEffectiveness;	// 3D array: moveTypeIdx x type1 x type2

const vector<string> allTypes = {
	"normal", "fire", "water", "electric", "grass", "ice", "fighting", "poison",
	"ground", "flying", "psychic", "bug", "rock", "ghost", "dragon", "dark",
	"steel", "fairy"
};
const TypeChart typeChart = {
	{0,  {{0, 1.0}, {1, 1.0}, {2, 1.0}, {3, 1.0}, {4, 1.0}, {5, 1.0}, {6, 1.0}, {7, 1.0}, {8, 1.0}, {9, 1.0}, {10, 1.0}, {11, 1.0}, {12, 0.5}, {13, 0}, {14, 1.0}, {15, 1.0}, {16, 0.5}, {17, 1.0}}},
	{1,    {{0, 1.0}, {1, 0.5}, {2, 0.5}, {3, 1.0}, {4, 2}, {5, 2}, {6, 1.0}, {7, 1.0}, {8, 1.0}, {9, 1.0}, {10, 1.0}, {11, 2}, {12, 0.5}, {13, 1.0}, {14, 0.5}, {15, 1.0}, {16, 2}, {17, 1.0}}},
	{2,   {{0, 1.0}, {1, 2}, {2, 0.5}, {3, 1.0}, {4, 0.5}, {5, 1.0}, {6, 1.0}, {7, 1.0}, {8, 2}, {9, 1.0}, {10, 1.0}, {11, 1.0}, {12, 2}, {13, 1.0}, {14, 0.5}, {15, 1.0}, {16, 1.0}, {17, 1.0}}},
	{3,{{0, 1.0}, {1, 1.0}, {2, 2}, {3, 0.5}, {4, 0.5}, {5, 1.0}, {6, 1.0}, {7, 1.0}, {8, 0}, {9, 2}, {10, 1.0}, {11, 1.0}, {12, 1.0}, {13, 1.0}, {14, 0.5}, {15, 1.0}, {16, 1.0}, {17, 1.0}}},
	{4,   {{0, 1.0}, {1, 0.5}, {2, 2}, {3, 1.0}, {4, 0.5}, {5, 1.0}, {6, 1.0}, {7, 0.5}, {8, 2}, {9, 0.5}, {10, 1.0}, {11, 0.5}, {12, 2}, {13, 1.0}, {14, 0.5}, {15, 1.0}, {16, 0.5}, {17, 1.0}}},
	{5,     {{0, 1.0}, {1, 0.5}, {2, 0.5}, {3, 1.0}, {4, 2}, {5, 0.5}, {6, 1.0}, {7, 1.0}, {8, 2}, {9, 2}, {10, 1.0}, {11, 1.0}, {12, 1.0}, {13, 1.0}, {14, 2}, {15, 1.0}, {16, 0.5}, {17, 1.0}}},
	{6,{{0, 2}, {1, 1.0}, {2, 1.0}, {3, 1.0}, {4, 1.0}, {5, 2}, {6, 1.0}, {7, 0.5}, {8, 1.0}, {9, 0.5}, {10, 0.5}, {11, 0.5}, {12, 2}, {13, 0}, {14, 1.0}, {15, 2}, {16, 2}, {17, 0.5}}},
	{7,  {{0, 1.0}, {1, 1.0}, {2, 1.0}, {3, 1.0}, {4, 2}, {5, 1.0}, {6, 1.0}, {7, 0.5}, {8, 0.5}, {9, 1.0}, {10, 1.0}, {11, 1.0}, {12, 0.5}, {13, 0.5}, {14, 1.0}, {15, 1.0}, {16, 0}, {17, 2}}},
	{8,  {{0, 1.0}, {1, 2}, {2, 1.0}, {3, 2}, {4, 0.5}, {5, 1.0}, {6, 1.0}, {7, 2}, {8, 1.0}, {9, 0}, {10, 1.0}, {11, 0.5}, {12, 2}, {13, 1.0}, {14, 1.0}, {15, 1.0}, {16, 2}, {17, 1.0}}},
	{9,  {{0, 1.0}, {1, 1.0}, {2, 1.0}, {3, 0.5}, {4, 2}, {5, 1.0}, {6, 2}, {7, 1.0}, {8, 1.0}, {9, 1.0}, {10, 1.0}, {11, 2}, {12, 0.5}, {13, 1.0}, {14, 1.0}, {15, 1.0}, {16, 0.5}, {17, 1.0}}},
	{10, {{0, 1.0}, {1, 1.0}, {2, 1.0}, {3, 1.0}, {4, 1.0}, {5, 1.0}, {6, 2}, {7, 2}, {8, 1.0}, {9, 1.0}, {10, 0.5}, {11, 1.0}, {12, 1.0}, {13, 1.0}, {14, 1.0}, {15, 0}, {16, 0.5}, {17, 1.0}}},
	{11,     {{0, 1.0}, {1, 0.5}, {2, 1.0}, {3, 1.0}, {4, 2}, {5, 1.0}, {6, 0.5}, {7, 0.5}, {8, 1.0}, {9, 0.5}, {10, 2}, {11, 1.0}, {12, 1.0}, {13, 0.5}, {14, 1.0}, {15, 2}, {16, 0.5}, {17, 0.5}}},
	{12,    {{0, 1.0}, {1, 2}, {2, 1.0}, {3, 1.0}, {4, 1.0}, {5, 2}, {6, 0.5}, {7, 1.0}, {8, 0.5}, {9, 2}, {10, 1.0}, {11, 2}, {12, 1.0}, {13, 1.0}, {14, 1.0}, {15, 1.0}, {16, 0.5}, {17, 1.0}}},
	{13,   {{0, 0}, {1, 1.0}, {2, 1.0}, {3, 1.0}, {4, 1.0}, {5, 1.0}, {6, 1.0}, {7, 1.0}, {8, 1.0}, {9, 1.0}, {10, 2}, {11, 1.0}, {12, 1.0}, {13, 2}, {14, 1.0}, {15, 0.5}, {16, 1.0}, {17, 1.0}}},
	{14,  {{0, 1.0}, {1, 1.0}, {2, 1.0}, {3, 1.0}, {4, 1.0}, {5, 1.0}, {6, 1.0}, {7, 1.0}, {8, 1.0}, {9, 1.0}, {10, 1.0}, {11, 1.0}, {12, 1.0}, {13, 1.0}, {14, 2}, {15, 1.0}, {16, 0.5}, {17, 0}}},
	{15,    {{0, 1.0}, {1, 1.0}, {2, 1.0}, {3, 1.0}, {4, 1.0}, {5, 1.0}, {6, 0.5}, {7, 1.0}, {8, 1.0}, {9, 1.0}, {10, 2}, {11, 1.0}, {12, 1.0}, {13, 2}, {14, 1.0}, {15, 0.5}, {16, 1.0}, {17, 0.5}}},
	{16,   {{0, 1.0}, {1, 0.5}, {2, 0.5}, {3, 0.5}, {4, 1.0}, {5, 2}, {6, 1.0}, {7, 1.0}, {8, 1.0}, {9, 1.0}, {10, 1.0}, {11, 1.0}, {12, 2}, {13, 1.0}, {14, 1.0}, {15, 1.0}, {16, 0.5}, {17, 2}}},
	{17,   {{0, 1.0}, {1, 0.5}, {2, 1.0}, {3, 1.0}, {4, 1.0}, {5, 1.0}, {6, 2}, {7, 0.5}, {8, 1.0}, {9, 1.0}, {10, 1.0}, {11, 1.0}, {12, 1.0}, {13, 1.0}, {14, 2}, {15, 2}, {16, 0.5}, {17, 1.0}}}
};
const vector<TypeCombo> typeCombos = {
	// Generation 1
	{4, 7}, 		// {grass, poison}
	{1, NO_TYPE},   // {fire}
	{1, 9}, 		// {fire, flying}
	{2, NO_TYPE},   // {water}
	{11, NO_TYPE},  // {bug}
	{9, 11},        // {bug, flying} 
	{7, 11},        // {bug, poison} 
	{0, 9},         // {flying, normal}
	{0, NO_TYPE},   // {normal}	
	{7, NO_TYPE},   // {poison}
	{3, NO_TYPE},   // {electric}
	{8, NO_TYPE},   // {ground}
	{7, 8},         // {ground, poison} 
	{17, NO_TYPE},  // {fairy}
	{0, 17},        // {fairy, normal} Wigglytuff
	{7, 9},         // {flying, poison}
	{4, 11},        // {bug, grass}
	{6, NO_TYPE},   // {fighting} all slow or weak
	{2, 6},         // {fighting, water}
	{10, NO_TYPE},  // {psychic}
	{2, 7},         // {poison, water}
	{8, 12},        // {ground, rock}
	{2, 10},        // {psychic, water}
	{3, 16},        // {electric, steel}
	{2, 5}, 		// {ice, water}
	{7, 13},        // {ghost, poison}
	{4, 10},        // {grass, psychic}
	{4, NO_TYPE},   // {grass}
	{10, 17},       // {fairy, psychic}
	{5, 10},        // {ice, psychic}
	{2, 9}, 		// {flying, water}
	{2, 12},        // {rock, water}
	{9, 12},        // {flying, rock}
	{5, 9},         // {flying, ice}
	{3, 9},         // {electric, flying}
	{14, NO_TYPE},  // {dragon}
	{9, 14},        // {dragon, flying}

	// Generation 2
	{2, 3},         // {electric, water}
	{9, 17},        // {fairy, flying}
	{9, 10},        // {flying, psychic}
	{2, 17},        // {fairy, water}
	{12, NO_TYPE},  // {rock}
	{4, 9}, 		// {flying, grass}
	{2, 8}, 		// {ground, water} swampert, whiscash, quagsire
	{15, NO_TYPE},  // {dark}
	{9, 15},        // {dark, flying}
	{13, NO_TYPE},  // {ghost}
	{0, 10},        // {normal, psychic}
	{11, 16},       // {bug, steel}
	{8, 9}, 		// {flying, ground}
	{8, 16},        // {ground, steel}
	{11, 12},       // {bug, rock} shuckle, armaldo
	{6, 11},        // {bug, fighting}
	{5, 15},        // {dark, ice}
	{1, 12},        // {fire, rock} magcargo
	{5, 8}, 		// {ground, ice}
	{9, 16},        // {flying, steel} skarmory
	{1, 15},        // {dark, fire}
	{2, 14},        // {dragon, water}
	{12, 15},       // {dark, rock}

	// Generation 3
	{1, 6},         // {fighting, fire}
	{2, 4}, 		// {grass, water}
	{4, 15},        // {dark, grass}
	{2, 11},        // {bug, water}
	{4, 6}, 		// {fighting, grass} breloom
	{8, 11},        // {bug, ground}
	{11, 13},       // {bug, ghost}
	{13, 15},       // {dark, ghost} sableye / spiritomb
	{16, 17},       // {fairy, steel}
	{12, 16},       // {rock, steel}
	{6, 10},        // {fighting, psychic}
	{2, 15},        // {dark, water}
	{1, 8}, 		// {fire, ground} camerupt
	{8, 14},        // {dragon, ground}
	{10, 12},       // {psychic, rock}
	{8, 10},        // {ground, psychic}
	{4, 12},        // {grass, rock} Cradily
	{5, NO_TYPE},   // {ice}
	{10, 16},       // {psychic, steel}
	{16, NO_TYPE},  // {steel}
	{10, 14},       // {dragon, psychic}

	// Generation 4
	{4, 8}, 		// {grass, ground}
	{2, 16},        // {steel, water} empoleon
	{0, 2}, 		// {normal, water}
	{9, 13},        // {flying, ghost}
	{7, 15},        // {dark, poison}
	{6, 16},        // {fighting, steel}
	{6, 7}, 		// {fighting, poison}
	{4, 5}, 		// {grass, ice}
	{5, 13},        // {ghost, ice}
	{3, 13},        // {electric, ghost}
	{14, 16},       // {dragon, steel}
	{1, 16},        // {fire, steel} heatran
	{13, 14},       // {dragon, ghost}

	// renegade platinum specific stuff (https://fredericdlugi.github.io/platinum-renegade-wiki/type_changes/)
	{1, 14},    	// {dragon, fire}
	{1, 17},    	// {fairy, fire}
	{6, 9}, 		// {fighting, flying} farfetchd
	{4, 17},    	// {fairy, grass}
	{3, 14},		// {dragon, electric}
	{13, 17},		// {fairy, ghost}
	{4, 14},        // {dragon, grass}
	{3, 11},        // {bug, electric}
	{11, 17},       // {bug, fairy}
	{11, 14},       // {bug, dragon}
	{14, 17},       // {dragon, fairy}
	{5, 12},        // {ice, rock}
	{3, 15},        // {dark, electric}
	{0, 6}, 		// {fighting, normal}
	{3, 6}, 		// {electric, fighting}

	// // Generation 5
	// {1, 10},        // {fire, psychic}
	// {4, 17},        // {fairy, grass}
	// {8, 15},        // {dark, ground}
	// {6, 15},        // {dark, fighting}
	// {0, 4}, 		// {grass, normal}
	// {2, 13},        // {ghost, water}
	// {3, 11},        // {bug, electric}
	// {4, 16},        // {grass, steel}
	// {1, 13},        // {fire, ghost}
	// {3, 8}, 		// {electric, ground}
	// {8, 13},        // {ghost, ground}
	// {15, 16},       // {dark, steel}
	// {14, 15},       // {dark, dragon}
	// {1, 11},        // {bug, fire}
	// {6, 12},        // {fighting, rock}
	// {9, NO_TYPE},   // {flying}
	// {1, 14},        // {dragon, fire}
	// {3, 14},        // {dragon, electric}
	// {5, 14},        // {dragon, ice}

	// // Generation 6
	// {0, 8}, 		// {ground, normal}
	// {0, 1}, 		// {fire, normal}
	// {13, 16},       // {ghost, steel}
	// {10, 15},       // {dark, psychic}
	// {7, 14},        // {dragon, poison}
	// {0, 3}, 		// {electric, normal}
	// {12, 14},       // {dragon, rock}
	// {5, 12},        // {ice, rock}
	// {6, 9}, 		// {fighting, flying}
	// {3, 17},        // {electric, fairy}
	// {12, 17},       // {fairy, rock}
	// {4, 13},        // {ghost, grass}
	// {10, 13},       // {ghost, psychic}
	// {1, 2},         // {fire, water}

	// // Generation 7
	// {5, 6},         // {fighting, ice}
	// {11, 17},       // {bug, fairy}
	// {1, 7},         // {fire, poison}
	// {0, 6},         // {fighting, normal}
	// {13, 17},       // {fairy, ghost}
	// {0, 14},        // {dragon, normal}
	// {6, 14},        // {dragon, fighting}
	// {7, 12},        // {poison, rock}
	// {6, 13},        // {fighting, ghost}

	// // Generation 8
	// {10, 11},       // {bug, psychic}
	// {4, 14},        // {dragon, grass}
	// {3, 7}, 		// {electric, poison}
	// {15, 17},       // {dark, fairy}
	// {0, 15},        // {dark, normal}
	// {5, 11},        // {bug, ice}
	// {3, 15},        // {dark, electric}
	// {3, 5},         // {electric, ice}

	// // Generation 9
	// {11, 15},       // {bug, dark}
	// {3, 6}, 		// {electric, fighting}
	// {0, 7}, 		// {normal, poison}
	// {1, 4}, 		// {fire, grass}
	// {7, 16},        // {poison, steel}
	// {6, 8}, 		// {fighting, ground}
	// {3, 12},        // {electric, rock}
	// {6, 17},        // {fairy, fighting}
	// {7, 10},        // {poison, psychic}
	// {7, 17},        // {fairy, poison}
};
const vector<Pokemon> potentialMembers = {
	// Generation 1
	{{1, 14}, "Levitate", "Charizard"},     					// {dragon, fire}, renegade-specific
	{{1, 17}, "Drought", "Ninetales"},   			    		// {fairy, fire}, renegade-specific
	{{10, NO_TYPE}, "Magic Guard", "Alakazam"},		            // {psychic}
	{{10, NO_TYPE}, "Magic Bounce", "Espeon"},		            // {psychic}
	// {{6, NO_TYPE}, "Guts"},   // {fighting}          machamp, riolu
	{{2, 5}, "Skill Link", "Cloyster"},				            // {ice, water}
	{{2, 5}, "Water Absorb", "Lapras"},				            // {ice, water}
	{{7, 13}, "Levitate", "Gengar"},				            // {ghost, poison}
	{{2, 10}, "Natural Cure", "Starmie"},			            // {psychic, water}
	{{9, 11}, "Technician", "Scyther"},				            // {bug, flying}
	{{2, NO_TYPE}, "Water Absorb", "Vaporeon"},		            // {water}
	{{3, NO_TYPE}, "Volt Absorb", "Jolteon"},		            // {electric}
	{{2, 12}, "Battle Armor", "Kabutops"},			            // {rock, water}
	{{9, 12}, "Rock Head", "Aerodactyl"},			            // {flying, rock}
	// {{3, 9}, "Static"},					// {electric, flying}   zapdos

	// Generation 2
	{{1, NO_TYPE}, "Adaptability", "Typhlosion"},		        // {fire}
	{{2, 15}, "Intimidate", "Feraligatr"},		        // {dark, water}, renegade-specific
	{{7, 9}, "Inner Focus", "Crobat"},				            // {flying, poison}
	{{11, 16}, "Technician", "Scizor"},				            // {bug, steel}
	{{6, 11}, "Skill Link", "Heracross"},			            // {bug, fighting}
	{{1, 15}, "Intimidate", "Houndoom"},				            // {dark, fire}
	// {{2, 14}, "Swift Swim"},			// {dragon, water}      kingdra
	// {{12, 15}, "Unnerve"},				// 	{dark, rock}		tyranitar
	
	// Generation 3
	{{1, 6}, "Speed Boost", "Blaziken"},			            // {fighting, fire}
	{{1, 6}, "Iron Fist", "Infernape"},				            // {fighting, fire}
	// {{2, 4}, "Rain Dish", "Ludicolo"}, 			                // {grass, water}
	{{10, 17}, "Synchronize", "Gardevoir"},       	            // {fairy, psychic}
	{{16, 17}, "Huge Power", "Mawile"},       	                // {fairy, steel}
	{{11, 14}, "Levitate", "Flygon"},       	        		// {bug, dragon}, renegade-specific
	{{2, 17}, "Marvel Scale", "Milotic"},		        		// {fairy, water}, renegade-specific
	// {{5, 12}, ""},        				// {ice, rock}			renegade glalie
	// {{9, 14}, ""},        				// {dragon, flying}		salamence
	{{10, 16}, "Iron Fist", "Metagross"},       	            // {psychic, steel}

	// Generation 4
	{{0, 9}, "Reckless", "Staraptor"},				            // {flying, normal}
	{{3, 15}, "Intimidate", "Luxray"},		            		// {dark, electric}, renegade-specific
	{{4, 7}, "Natural Cure", "Roserade"},			            // {grass, poison}
	{{13, 17}, "Levitate", "Mismagius"},				        // {fairy, ghost}, renegade-specific
	{{0, 6}, "Scrappy", "Lopunny"},				                // {fighting, normal}
	{{8, 14}, "Rough Skin", "Garchomp"},				        // {dragon, ground}
	{{6, 16}, "Adaptability", "Lucario"},				        // {fighting, steel}
	{{7, 15}, "Sniper", "Drapion"},				                // {dark, poison}
	{{5, 15}, "Technician", "Weavile"},				            // {dark, ice}
	{{3, 6}, "Motor Drive", "Electivire"},	            		// {electric, fighting}, renegade-specific
	{{9, 17}, "Serene Grace", "Togekiss"},			            // {fairy, flying}
	{{5, 8}, "Thick Fat", "Mamoswine"},				            // {ground, ice}
	{{3, 13}, "Levitate", "Rotom"},				                // {electric, ghost}
	{{2, 3}, "Levitate", "Rotom-Wash"},				            // {electric, water}
	// {{13, 14}, ""},       // {dragon, ghost}		giratina
	// // {{4, 8}, ""}, 		// {grass}				shaymin-l
	// // {{4, 9}, ""}, 		// {flying, grass}		shaymin-s
};

void initializeAllTypesMap() {
	for (size_t i = 0; i < allTypes.size(); ++i) {
		allTypesMap[allTypes[i]] = i;
	}
}

void precomputeTypeEffectiveness() {
	// Precompute type effectiveness for all combinations of moveType, type1, type2
	for (size_t moveType = 0; moveType < NUM_TYPES; ++moveType) {
		for (size_t t1 = 0; t1 <= NUM_TYPES; ++t1) {
			for (size_t t2 = 0; t2 <= NUM_TYPES; ++t2) {
				size_t idx1 = (t1 == NUM_TYPES) ? NO_TYPE : t1;
				size_t idx2 = (t2 == NUM_TYPES) ? NO_TYPE : t2;
				double mult = 1.0;
				const auto it = typeChart.find(moveType);
				if (it != typeChart.end()) {
					const auto& vsMap = it->second;
					if (idx1 != NO_TYPE) {
						auto it1 = vsMap.find(idx1);
						mult *= (it1 != vsMap.end()) ? it1->second : 1.0;
					}
					if (idx2 != NO_TYPE && idx2 != idx1) {
						auto it2 = vsMap.find(idx2);
						mult *= (it2 != vsMap.end()) ? it2->second : 1.0;
					}
				}
				precomputedTypeEffectiveness[moveType][t1][t2] = mult;
			}
		}
	}
}

size_t getGlobalTypeIndex(size_t localIdx, const vector<string>& localTypes) {
	if (localIdx == NO_TYPE || localIdx >= localTypes.size()) return NO_TYPE;

	const string& typeStr = localTypes[localIdx];	// get the string version
	auto it = allTypesMap.find(typeStr);	// try to find it in the global list
	return (it != allTypesMap.end()) ? it->second : NO_TYPE; // return the index if found, or NO_TYPE if not
}

double typeEffectiveness(
	const size_t& moveTypeIdx, 
	const TypeCombo& targetTc, 
	const vector<string>& types,
	const vector<TypeCombo>& combos,
	const bool& useGlobalTypes,
	const string& ability
) {
	double mult = 1.0;
	const auto& [type1, type2] = targetTc;

	size_t actualMoveTypeIdx;
	size_t actualTargetType1Idx;
	size_t actualTargetType2Idx;
	if (useGlobalTypes) {
		actualMoveTypeIdx = moveTypeIdx;
		actualTargetType1Idx = type1;
		actualTargetType2Idx = type2;
	} else {
		actualMoveTypeIdx = getGlobalTypeIndex(moveTypeIdx, types);
		actualTargetType1Idx = getGlobalTypeIndex(type1, types);
		actualTargetType2Idx = getGlobalTypeIndex(type2, types);
	}

	if (actualMoveTypeIdx == NO_TYPE || actualTargetType1Idx == NO_TYPE) {
		cerr << "Error: Invalid type indices in typeEffectiveness: "
				<< "moveTypeIdx=" << moveTypeIdx
				<< ", type1=" << type1 << ", type2=" << type2
				<< ", actualMoveTypeIdx=" << actualMoveTypeIdx
				<< ", actualTargetType1Idx=" << actualTargetType1Idx
				<< ", actualTargetType2Idx=" << actualTargetType2Idx << endl;
		return 1.0; // If the move type or target type is not valid, return neutral effectiveness
	}

	size_t t1 = (actualTargetType1Idx == NO_TYPE) ? NUM_TYPES : actualTargetType1Idx;
	size_t t2 = (actualTargetType2Idx == NO_TYPE) ? NUM_TYPES : actualTargetType2Idx;
	if (actualMoveTypeIdx < NUM_TYPES && t1 <= NUM_TYPES && t2 <= NUM_TYPES) {
		mult = precomputedTypeEffectiveness[actualMoveTypeIdx][t1][t2];
	} else {
		// todo: error printing
		mult = 1.0;
	}

	mult *= getAbilityTypeModifier(ability, actualMoveTypeIdx, types);

	return mult;
}

double getAbilityTypeModifier(const string& ability, size_t moveTypeIdx, const vector<string>& types) {
	// future work: 
	// offensive abilities that nullify resistances/immunities, like Scrappy
	// defensive abilities that nullify neutrals/resistances, like Wonder Guard
	// use a map for abilities to avoid hardcoding
	// use indices into an ability table instead of strings

	if (ability.empty() || moveTypeIdx >= NUM_TYPES) return 1.0;

	// Immunity abilities
	if (ability == "Levitate" && types[moveTypeIdx] == "ground")
		return 0.0;
	if ((
		ability == "Volt Absorb" || 
		ability == "Motor Drive" || 
		ability == "Lightning Rod"
	) && types[moveTypeIdx] == "electric")
		return 0.0;
	if (ability == "Water Absorb" && types[moveTypeIdx] == "water")
		return 0.0;
	if (ability == "Flash Fire" && types[moveTypeIdx] == "fire")
		return 0.0;

	// Resistance abilities
	if (ability == "Thick Fat" && types[moveTypeIdx] == "fire")
		return 0.5;
	if (ability == "Thick Fat" && types[moveTypeIdx] == "ice")
		return 0.5;
	// todo: dry skin

	// Default case
	return 1.0;
}
