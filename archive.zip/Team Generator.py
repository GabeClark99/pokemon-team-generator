# type combo value source: https://www.reddit.com/r/pokemon/comments/4xawyi/i_created_a_table_listing_all_possible_type/
# type chart source: https://github.com/zonination/pokemon-chart/blob/master/chart.csv

import itertools

fileName_typeChart = "typeChart.csv"
fileName_typeValues = "attTypeValues.csv"
fileName_typeCombos = "defTypeComboValues.csv"

class PokemonType:
    def __init__(self, name, supEff, nvEff, imm, neu):
        self.name = name
        self.supEff = supEff
        self.nvEff = nvEff
        self.imm = imm
        self.neu = neu
        self.offScore = -1.0

class TypeCombo:
    def __init__(self, typeA, typeB, defScore):
        self.typeA = typeA
        self.typeB = typeB
        self.defScore = defScore
        # self.offScore = 

    def getComboName(self):
        return self.typeA.name + "/" + self.typeB.name

class Team:
    def __init__(self, members):
        self.members = members
        self.types = []
        self.offScore = -1.0
        self.defScore = -1.0

    def calcTypes(self):
        for combo in self.members:
            typeA = combo.typeA
            typeB = combo.typeB

            if typeA not in self.types:
                self.types.append(typeA)
                print("appended " + typeA.name)
            if typeB not in self.types:
                self.types.append(typeB)
                print("appended " + typeB.name)

            print("len(self.types)=" + str(len(self.types)))

# i really should just combine the value data and chart data all into one file instead...
def ImportTypeValues(pTypes):
    f = open(fileName_typeValues, "r")
    for line in f:
        lineData = line.strip('\n').split(',')
        typeName = lineData[0]
        typeValue = lineData[1]

        pType = next(t for t in pTypes if t.name == typeName)
        pType.offScore = float(typeValue)
    f.close()
    return pTypes

def ImportTypes():
    attackingTypes = []
    f = open(fileName_typeChart, "r")
    typeNames = f.readline().strip('\n').split(',')[1:]
    for line in f:
        lineData = line.strip('\n').split(',')
        typeName = lineData[0]
        lineWeak = []
        lineRes = []
        lineImm = []
        lineNeu = []

        i = 0
        for value in lineData[1:]:
            attackingType = typeNames[i]

            match value:
                case "2":
                    lineWeak.append(attackingType)
                case "1":
                    lineNeu.append(attackingType)
                case "0.5":
                    lineRes.append(attackingType)
                case "0":
                    lineImm.append(attackingType)
                case _:
                    raise ValueError("Invalid type chart case: \"" + str(value) + "\"")

            i += 1

        attackingTypes.append(PokemonType(typeName, lineWeak, lineRes, lineImm, lineNeu))

    f.close()
    return ImportTypeValues(attackingTypes)

def ImportTypeCombos(pTypes):
    defendingTypeCombos = []
    f = open(fileName_typeCombos, "r")
    for line in f:
        lineData = line.strip('\n').split(',')
        typeA = next(t for t in pTypes if t.name == lineData[0])
        typeB = next(t for t in pTypes if t.name == lineData[1])
        # print("typeA.name=" + typeA.name + ", typeB.name=" + typeB.name)
        defendingTypeCombos.append(TypeCombo(typeA, typeB, lineData[2]))
    f.close()
    return defendingTypeCombos

def SetAttackingScores(attackingTypes, defendingTypeCombos):
    for attType in attackingTypes:
        print("attType.name=" + attType.name)
        totalScore = 0.0
        for defCombo in defendingTypeCombos:
            comboScore = 0.0
            # print("\t" + defCombo.nameA + "," + defCombo.nameB)

            if defCombo.nameA in attType.supEff:
                if defCombo.nameB in attType.supEff:
                    comboScore += 4
                elif defCombo.nameB in attType.neu:
                    comboScore += 2
                elif defCombo.nameB in attType.nvEff:
                    comboScore += 1
                elif defCombo.nameB in attType.imm:
                    comboScore = 0
                else:
                    raise Exception("No matching case for defCombo.nameB=\"" + defCombo.nameB + "\"")
                
            elif defCombo.nameA in attType.neu:
                if defCombo.nameB in attType.supEff:
                    comboScore += 2
                elif defCombo.nameB in attType.neu:
                    comboScore += 1
                elif defCombo.nameB in attType.nvEff:
                    comboScore += 0.5
                elif defCombo.nameB in attType.imm:
                    comboScore = 0
                else:
                    raise Exception("No matching case for defCombo.nameB=\"" + defCombo.nameB + "\"")
                
            elif defCombo.nameA in attType.nvEff:
                if defCombo.nameB in attType.supEff:
                    comboScore += 1
                elif defCombo.nameB in attType.neu:
                    comboScore += 0.5
                elif defCombo.nameB in attType.nvEff:
                    comboScore += 0.25
                elif defCombo.nameB in attType.imm:
                    comboScore = 0
                else:
                    raise Exception("No matching case for defCombo.nameB=\"" + defCombo.nameB + "\"")
                
            elif defCombo.nameA in attType.imm:
                comboScore = 0
            else:
                raise Exception("No matching case for defCombo.nameA=\"" + defCombo.nameA + "\"")

            # print("\tcomboScore=" + str(comboScore))
            totalScore += comboScore
        attType.atkScore = totalScore
        print("score=" + str(totalScore))
    return

def PrintPermutations(perms):
    i = 0
    for perm in perms:
        print("permutation: " + str(i))
        for t in perm:
            print("\t" + t.getComboName())
        i += 1
        # if i >= 10: break

# import types and their values
pTypes = ImportTypes()
typeCombos = ImportTypeCombos(pTypes)

# --- generate typeCombo permutations for a size of 6 ---
perms = itertools.permutations(typeCombos[:15], 6)
PrintPermutations(perms)
